package com.endless.fortune.network;

import com.endless.fortune.EndlessFortune;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ActivateUltimatePayload() implements class_8710 {

    public static final ActivateUltimatePayload INSTANCE = new ActivateUltimatePayload();
    public static final class_8710.class_9154<ActivateUltimatePayload> ID = new class_8710.class_9154<>(
            class_2960.method_60655(EndlessFortune.MOD_ID, "activate_ultimate"));
    public static final class_9139<class_9129, ActivateUltimatePayload> CODEC = class_9139.method_56431(INSTANCE);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
