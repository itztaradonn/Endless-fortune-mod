package com.endless.fortune.command;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.item.ModItems;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class WithdrawCommand {

    private static final double WITHDRAW_PERCENTAGE = 20.0;

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("withdraw")
                .executes(context -> {
                    class_2168 source = context.getSource();
                    class_3222 player = source.method_9207();
                    return executeWithdraw(player);
                })
        );
    }

    private static int executeWithdraw(class_3222 player) {
        PlayerData data = PlayerDataManager.get(player);

        double currentLuck = data.getLuck();

        // Check if player has enough luck
        if (currentLuck < WITHDRAW_PERCENTAGE) {
            player.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("You need at least ").method_27692(class_124.field_1061))
                    .method_10852(class_2561.method_43470(String.format("%.0f%%", WITHDRAW_PERCENTAGE)).method_27695(class_124.field_1054, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" luck to withdraw!").method_27692(class_124.field_1061)));
            player.method_64398(class_2561.method_43470("  Current luck: ").method_27692(class_124.field_1080)
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", currentLuck)).method_27692(class_124.field_1061)));
            return 0;
        }

        // Check inventory space
        if (player.method_31548().method_7376() == -1) {
            player.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("Your inventory is full!").method_27692(class_124.field_1061)));
            return 0;
        }

        // Reduce luck
        double newLuck = currentLuck - WITHDRAW_PERCENTAGE;
        data.setLuck(newLuck);
        data.checkAndUnlockAbilities(); // Re-check abilities (some may be locked now)
        PlayerDataManager.save(player.method_5667());

        // Give Potion of Fortune
        class_1799 potion = new class_1799(ModItems.POTION_OF_FORTUNE);
        player.method_31548().method_7394(potion);

        // Effects
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14627,
                class_3419.field_15248, 1.0f, 0.5f);
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14978,
                class_3419.field_15248, 1.0f, 1.0f);

        player.method_7353(
                class_2561.method_43470("Withdrawn ").method_27692(class_124.field_1065)
                        .method_10852(class_2561.method_43470(String.format("%.0f%%", WITHDRAW_PERCENTAGE)).method_27695(class_124.field_1061, class_124.field_1067))
                        .method_10852(class_2561.method_43470(" luck → received Potion of Fortune").method_27692(class_124.field_1080)),
                true);

        return 1;
    }
}
