package com.endless.fortune.command;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillAbility;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_12087;
import net.minecraft.class_12094;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

public class LuckCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("luck")
                .executes(LuckCommand::showLuck)
                .then(class_2170.method_9247("set")
                        .requires(source -> source.method_75037().hasPermission(new class_12087.class_12089(class_12094.field_63198)))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .then(class_2170.method_9244("amount", DoubleArgumentType.doubleArg(0.0, 100.0))
                                        .executes(LuckCommand::setLuck))))
                .then(class_2170.method_9247("add")
                        .requires(source -> source.method_75037().hasPermission(new class_12087.class_12089(class_12094.field_63198)))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .then(class_2170.method_9244("amount", DoubleArgumentType.doubleArg(-100.0, 100.0))
                                        .executes(LuckCommand::addLuck))))
                .then(class_2170.method_9247("info")
                        .executes(LuckCommand::showDetailedInfo))
        );
    }

    private static int showLuck(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            PlayerData data = PlayerDataManager.get(player);
            Skill skill = data.getSkill();

            class_5250 msg = class_2561.method_43470("Luck: ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", data.getLuck())).method_27695(getLuckColor(data.getLuck()), class_124.field_1067));
            if (skill != null) {
                msg = msg.method_10852(class_2561.method_43470(" | Skill: ").method_27692(class_124.field_1080))
                        .method_10852(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067))
                        .method_10852(class_2561.method_43470(" | Abilities: ").method_27692(class_124.field_1080))
                        .method_10852(class_2561.method_43470(data.getUnlockedAbilities().size() + "/" + skill.getAbilities().size()).method_27692(class_124.field_1068));
            }
            player.method_7353(msg, true);
        }
        return 1;
    }

    private static int showDetailedInfo(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            PlayerData data = PlayerDataManager.get(player);
            Skill skill = data.getSkill();

            player.method_64398(class_2561.method_43470("═══════════════════════════════════════").method_27692(class_124.field_1065));
            player.method_64398(class_2561.method_43470("  ★ Detailed Luck Info ★").method_27695(class_124.field_1065, class_124.field_1067));
            player.method_64398(class_2561.method_43470("═══════════════════════════════════════").method_27692(class_124.field_1065));
            player.method_64398(class_2561.method_43470("  Luck: ").method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", data.getLuck())).method_27695(getLuckColor(data.getLuck()), class_124.field_1067)));

            if (skill != null) {
                player.method_64398(class_2561.method_43470(""));
                player.method_64398(class_2561.method_43470("  Skill: ").method_27692(class_124.field_1054)
                        .method_10852(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067))
                        .method_10852(class_2561.method_43470(" [" + skill.getCategory().getDisplayName() + "]").method_27692(skill.getCategory().getColor())));
                player.method_64398(class_2561.method_43470("  " + skill.getDescription()).method_27695(class_124.field_1063, class_124.field_1056));
                player.method_64398(class_2561.method_43470(""));
                player.method_64398(class_2561.method_43470("  Abilities:").method_27695(class_124.field_1075, class_124.field_1067));

                for (SkillAbility ability : skill.getAbilities()) {
                    boolean unlocked = data.hasUnlockedAbility(ability.id());
                    if (unlocked) {
                        player.method_64398(class_2561.method_43470("    ✓ ").method_27692(class_124.field_1060)
                                .method_10852(class_2561.method_43470(ability.name()).method_27695(class_124.field_1068, class_124.field_1067))
                                .method_10852(class_2561.method_43470(String.format(" (%.0f%%)", ability.requiredLuck())).method_27692(class_124.field_1063)));
                    } else {
                        player.method_64398(class_2561.method_43470("    ✗ ").method_27692(class_124.field_1061)
                                .method_10852(class_2561.method_43470(ability.name()).method_27692(class_124.field_1080))
                                .method_10852(class_2561.method_43470(String.format(" (Requires %.0f%% Luck)", ability.requiredLuck())).method_27692(class_124.field_1063)));
                    }
                    player.method_64398(class_2561.method_43470("      " + ability.description()).method_27695(class_124.field_1063, class_124.field_1056));
                }
            }

            player.method_64398(class_2561.method_43470("═══════════════════════════════════════").method_27692(class_124.field_1065));
            player.method_64398(class_2561.method_43470("  Loot Upgrade Chance: ").method_27692(class_124.field_1054)
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", data.getLuck() / 2.0)).method_27692(class_124.field_1076)));
            player.method_64398(class_2561.method_43470("═══════════════════════════════════════").method_27692(class_124.field_1065));
        }
        return 1;
    }

    private static int setLuck(CommandContext<class_2168> context) {
        try {
            class_3222 target = class_2186.method_9315(context, "player");
            double amount = DoubleArgumentType.getDouble(context, "amount");
            PlayerData data = PlayerDataManager.get(target);
            data.setLuck(amount);
            data.checkAndUnlockAbilities();
            PlayerDataManager.save(target.method_5667());

            context.getSource().method_45068(class_2561.method_43470("Set " + target.method_5477().getString() + "'s luck to " + String.format("%.1f%%", amount))
                    .method_27692(class_124.field_1060));
            target.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("Your luck has been set to ").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", amount)).method_27695(class_124.field_1060, class_124.field_1067)));
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
        }
        return 1;
    }

    private static int addLuck(CommandContext<class_2168> context) {
        try {
            class_3222 target = class_2186.method_9315(context, "player");
            double amount = DoubleArgumentType.getDouble(context, "amount");
            PlayerData data = PlayerDataManager.get(target);
            double oldLuck = data.getLuck();
            data.addLuck(amount);
            data.checkAndUnlockAbilities();
            PlayerDataManager.save(target.method_5667());

            context.getSource().method_45068(class_2561.method_43470("Added " + String.format("%.1f%%", amount) + " luck to " +
                    target.method_5477().getString() + " (" + String.format("%.1f%% → %.1f%%", oldLuck, data.getLuck()) + ")")
                    .method_27692(class_124.field_1060));
            target.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470(String.format("%.1f%% luck added! ", amount)).method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(String.format("(%.1f%% → %.1f%%)", oldLuck, data.getLuck())).method_27692(class_124.field_1080)));
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
        }
        return 1;
    }

    private static class_124 getLuckColor(double luck) {
        if (luck >= 75) return class_124.field_1076;
        if (luck >= 50) return class_124.field_1065;
        if (luck >= 25) return class_124.field_1054;
        if (luck >= 10) return class_124.field_1060;
        return class_124.field_1080;
    }
}
