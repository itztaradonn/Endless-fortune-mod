package com.endless.fortune.command;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillCategory;
import com.endless.fortune.skill.SkillManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_12087;
import net.minecraft.class_12094;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;

public class SkillCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("skill")
                .executes(SkillCommand::showSkill)
                .then(class_2170.method_9247("info")
                        .then(class_2170.method_9244("skillId", StringArgumentType.word())
                                .suggests((context, builder) -> {
                                    SkillManager.getAllSkills().forEach(s -> builder.suggest(s.getId()));
                                    return builder.buildFuture();
                                })
                                .executes(SkillCommand::showSkillInfo)))
                .then(class_2170.method_9247("list")
                        .executes(SkillCommand::listSkills))
                .then(class_2170.method_9247("set")
                        .requires(source -> source.method_75037().hasPermission(new class_12087.class_12089(class_12094.field_63198)))
                        .then(class_2170.method_9244("player", class_2186.method_9305())
                                .then(class_2170.method_9244("skillId", StringArgumentType.word())
                                        .suggests((context, builder) -> {
                                            SkillManager.getAllSkills().forEach(s -> builder.suggest(s.getId()));
                                            return builder.buildFuture();
                                        })
                                        .executes(SkillCommand::setSkill))))
        );
    }

    private static int showSkill(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            PlayerData data = PlayerDataManager.get(player);
            Skill skill = data.getSkill();

            if (skill == null) {
                player.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                        .method_10852(class_2561.method_43470("You don't have a skill yet! Rejoin the server.").method_27692(class_124.field_1061)));
                return 0;
            }

            player.method_64398(class_2561.method_43470("Your Skill: ").method_27695(class_124.field_1065, class_124.field_1067)
                    .method_10852(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067))
                    .method_10852(class_2561.method_43470(" [" + skill.getCategory().getDisplayName() + "]").method_27692(skill.getCategory().getColor())));
            player.method_64398(class_2561.method_43470(skill.getDescription()).method_27695(class_124.field_1063, class_124.field_1056));
            player.method_64398(class_2561.method_43470("Abilities:").method_27695(class_124.field_1075, class_124.field_1067));

            skill.getAbilities().forEach(ability -> {
                boolean unlocked = data.hasUnlockedAbility(ability.id());
                class_124 nameColor = unlocked ? class_124.field_1068 : class_124.field_1080;
                String prefix = unlocked ? "✓ " : "✗ ";
                class_124 prefixColor = unlocked ? class_124.field_1060 : class_124.field_1061;

                player.method_64398(class_2561.method_43470(prefix).method_27692(prefixColor)
                        .method_10852(class_2561.method_43470(ability.name()).method_27695(nameColor, unlocked ? class_124.field_1067 : class_124.field_1056))
                        .method_10852(class_2561.method_43470(String.format(" (%.0f%%)", ability.requiredLuck())).method_27692(class_124.field_1063)));
            });
        }
        return 1;
    }

    private static int showSkillInfo(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            String skillId = StringArgumentType.getString(context, "skillId");
            Skill skill = SkillManager.getSkill(skillId);
            if (skill == null) {
                player.method_7353(class_2561.method_43470("Unknown skill: ").method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43470(skillId).method_27692(class_124.field_1054)), false);
                return 0;
            }

            player.method_7353(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067)
                    .method_10852(class_2561.method_43470(" [" + skill.getCategory().getDisplayName() + "]").method_27692(skill.getCategory().getColor())), false);
            skill.getAbilities().forEach(ability -> player.method_7353(
                    class_2561.method_43470(String.format("%.0f%% ", ability.requiredLuck())).method_27692(class_124.field_1065)
                            .method_10852(class_2561.method_43470(ability.name()).method_27692(class_124.field_1054))
                            .method_10852(class_2561.method_43470(": ").method_27692(class_124.field_1063))
                            .method_10852(class_2561.method_43470(ability.description()).method_27692(class_124.field_1080)),
                    false));
        }
        return 1;
    }

    private static int listSkills(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        if (source.method_9228() instanceof class_3222 player) {
            player.method_64398(class_2561.method_43470("All Skills:").method_27695(class_124.field_1065, class_124.field_1067));

            for (SkillCategory category : SkillCategory.values()) {
                player.method_64398(class_2561.method_43470(category.getDisplayName()).method_27695(category.getColor(), class_124.field_1067, class_124.field_1073));

                for (Skill skill : SkillManager.getSkillsByCategory(category)) {
                    class_2561 skillText = class_2561.method_43470("- ").method_27692(category.getColor())
                            .method_10852(class_2561.method_43470(skill.getName()).method_27692(class_124.field_1068)
                                    .method_27694(style -> style
                                            .method_10949(new class_2568.class_10613(
                                                    class_2561.method_43470(skill.getDescription() + "\n\nAbilities: " + skill.getAbilities().size())
                                                            .method_27692(class_124.field_1080)))));
                    player.method_64398(skillText);
                }
            }
        }
        return 1;
    }

    private static int setSkill(CommandContext<class_2168> context) {
        try {
            class_3222 target = class_2186.method_9315(context, "player");
            String skillId = StringArgumentType.getString(context, "skillId");
            Skill skill = SkillManager.getSkill(skillId);

            if (skill == null) {
                context.getSource().method_9213(class_2561.method_43470("Unknown skill: " + skillId));
                return 0;
            }

            PlayerData data = PlayerDataManager.get(target);
            data.setSkillId(skillId);
            data.checkAndUnlockAbilities();
            PlayerDataManager.save(target.method_5667());

            context.getSource().method_45068(class_2561.method_43470("Set " + target.method_5477().getString() + "'s skill to " + skill.getName())
                    .method_27692(class_124.field_1060));
            target.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("Your skill has been set to ").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067)));
        } catch (Exception e) {
            context.getSource().method_9213(class_2561.method_43470("Error: " + e.getMessage()));
        }
        return 1;
    }
}
