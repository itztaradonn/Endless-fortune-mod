package com.endless.fortune.skill;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.*;
import net.minecraft.class_124;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import java.util.*;

public class BlockBreakHandler {

    private static final Random RANDOM = new Random();

    // Prevent recursive block breaking
    private static boolean isBreaking = false;

    public static void register() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof class_3222 serverPlayer)) return;
            if (!(world instanceof class_3218 serverWorld)) return;

            PlayerData data = PlayerDataManager.get(serverPlayer);
            if (data.getSkill() == null) return;

            // ═══════════════════════════════
            // MINER ABILITIES
            // ═══════════════════════════════
            if (state.method_26164(class_3481.field_33715)) {
                handleMinerAbilities(serverPlayer, serverWorld, pos, state, data);
            }

            // ═══════════════════════════════
            // LUMBERJACK ABILITIES
            // ═══════════════════════════════
            if (state.method_26164(class_3481.field_15475)) {
                handleLumberjackAbilities(serverPlayer, serverWorld, pos, state, data);
            }
            if (state.method_26164(class_3481.field_15503)) {
                handleLeafBreak(serverPlayer, serverWorld, pos, state, data);
            }

            // ═══════════════════════════════
            // FARMER ABILITIES
            // ═══════════════════════════════
            if (state.method_26204() instanceof class_2302 crop) {
                if (crop.method_9825(state)) {
                    handleFarmerAbilities(serverPlayer, serverWorld, pos, state, data);
                }
            }
        });
    }

    // ═══════════════════════════════
    // MINER
    // ═══════════════════════════════
    private static void handleMinerAbilities(class_3222 player, class_3218 world, class_2338 pos, class_2680 state, PlayerData data) {
        // Vein Riches: 15% chance to double ore drops
        if (data.hasUnlockedAbility("miner_double_ore")) {
            if (isOre(state) && RANDOM.nextFloat() < 0.15f) {
                class_2248.method_9511(state, world, pos, null, player, player.method_6047());
                player.method_7353(class_2561.method_43470("  ✧ Double ore!").method_27695(class_124.field_1075, class_124.field_1056), true);
            }
        }

        // Gem Finder: Small chance to find gems when mining stone
        if (data.hasUnlockedAbility("miner_gem_finder")) {
            if (isStone(state) && RANDOM.nextFloat() < 0.02f) {
                class_1799 gem = getRandomGem();
                dropItem(world, pos, gem);
                player.method_7353(class_2561.method_43470("  ✧ You found a gem!").method_27695(class_124.field_1060, class_124.field_1056), true);
                world.method_8396(null, pos, class_3417.field_14627, class_3419.field_15245, 1.0f, 1.5f);
            }
        }

        // Tunnel Bore: 5% chance to break adjacent blocks
        if (data.hasUnlockedAbility("miner_blast") && !isBreaking) {
            if (RANDOM.nextFloat() < 0.05f) {
                isBreaking = true;
                try {
                    for (class_2338 adjacent : getAdjacentPositions(pos)) {
                        class_2680 adjState = world.method_8320(adjacent);
                        if (adjState.method_26164(class_3481.field_33715) && !adjState.method_26215()) {
                            world.method_8651(adjacent, true, player);
                        }
                    }
                    player.method_7353(class_2561.method_43470("  ✧ Tunnel Bore!").method_27695(class_124.field_1054, class_124.field_1056), true);
                } finally {
                    isBreaking = false;
                }
            }
        }

        // Motherlode ultimate tracking
        if (data.hasUnlockedAbility("miner_motherlode")) {
            UUID uuid = player.method_5667();
            int count = SkillAbilityHandler.BLOCKS_MINED.getOrDefault(uuid, 0) + 1;
            SkillAbilityHandler.BLOCKS_MINED.put(uuid, count);
            if (count >= 64) {
                SkillAbilityHandler.onMinerUltimate(player);
                SkillAbilityHandler.BLOCKS_MINED.put(uuid, 0);
            }
        }

        // If Motherlode is active, double ore drops
        if (SkillAbilityHandler.isMotherlodeActive(player.method_5667())) {
            if (isOre(state)) {
                class_2248.method_9511(state, world, pos, null, player, player.method_6047());
            }
        }
    }

    // ═══════════════════════════════
    // LUMBERJACK
    // ═══════════════════════════════
    private static void handleLumberjackAbilities(class_3222 player, class_3218 world, class_2338 pos, class_2680 state, PlayerData data) {
        // Timber!: 20% chance to double log drops
        if (data.hasUnlockedAbility("lumber_double_wood")) {
            if (RANDOM.nextFloat() < 0.20f) {
                class_2248.method_9511(state, world, pos, null, player, player.method_6047());
                player.method_7353(class_2561.method_43470("  ✧ Double logs!").method_27695(class_124.field_1060, class_124.field_1056), true);
            }
        }

        // Strip Harvest: Breaking logs drops extra sticks
        if (data.hasUnlockedAbility("lumber_strip")) {
            int stickCount = 1 + RANDOM.nextInt(2);
            dropItem(world, pos, new class_1799(class_1802.field_8600, stickCount));
        }

        // Tree Feller: 10% chance to break all connected logs
        if (data.hasUnlockedAbility("lumber_fell") && !isBreaking) {
            if (RANDOM.nextFloat() < 0.10f) {
                isBreaking = true;
                try {
                    int broken = fellTree(world, pos, player, 32);
                    if (broken > 1) {
                        player.method_7353(class_2561.method_43470("  ✧ Tree Feller! (" + broken + " logs)").method_27695(class_124.field_1060, class_124.field_1067), true);
                        world.method_8396(null, pos, class_3417.field_15152.comp_349(), class_3419.field_15245, 0.5f, 1.2f);
                    }
                } finally {
                    isBreaking = false;
                }
            }
        }

        // Timber Storm ultimate tracking
        if (data.hasUnlockedAbility("lumber_timberstorm")) {
            UUID uuid = player.method_5667();
            int count = SkillAbilityHandler.LOGS_CHOPPED.getOrDefault(uuid, 0) + 1;
            SkillAbilityHandler.LOGS_CHOPPED.put(uuid, count);
            if (count >= 32) {
                SkillAbilityHandler.onLumberjackUltimate(player);
                SkillAbilityHandler.LOGS_CHOPPED.put(uuid, 0);
            }
        }
    }

    private static void handleLeafBreak(class_3222 player, class_3218 world, class_2338 pos, class_2680 state, PlayerData data) {
        // Auto Replant: 30% chance to drop saplings from leaves
        if (data.hasUnlockedAbility("lumber_replant")) {
            if (RANDOM.nextFloat() < 0.30f) {
                dropItem(world, pos, new class_1799(class_1802.field_17535, 1));
            }
        }
    }

    // ═══════════════════════════════
    // FARMER
    // ═══════════════════════════════
    private static void handleFarmerAbilities(class_3222 player, class_3218 world, class_2338 pos, class_2680 state, PlayerData data) {
        // Bountiful Harvest: 20% chance to double crop drops
        if (data.hasUnlockedAbility("farmer_double_harvest")) {
            if (RANDOM.nextFloat() < 0.20f) {
                class_2248.method_9511(state, world, pos, null, player, player.method_6047());
                player.method_7353(class_2561.method_43470("  ✧ Bountiful Harvest!").method_27695(class_124.field_1060, class_124.field_1056), true);
            }
        }

        // Harvest Moon ultimate tracking
        if (data.hasUnlockedAbility("farmer_harvestmoon")) {
            UUID uuid = player.method_5667();
            int count = SkillAbilityHandler.CROPS_HARVESTED.getOrDefault(uuid, 0) + 1;
            SkillAbilityHandler.CROPS_HARVESTED.put(uuid, count);
            if (count >= 20) {
                SkillAbilityHandler.onFarmerUltimate(player);
                SkillAbilityHandler.CROPS_HARVESTED.put(uuid, 0);
            }
        }
    }

    // ═══════════════════════════════
    // UTILITY METHODS
    // ═══════════════════════════════

    private static boolean isOre(class_2680 state) {
        return state.method_26164(class_3481.field_23062) || state.method_26164(class_3481.field_28988) ||
                state.method_26164(class_3481.field_28989) || state.method_26164(class_3481.field_29194) ||
                state.method_26164(class_3481.field_28991) || state.method_26164(class_3481.field_28990) ||
                state.method_26164(class_3481.field_29195) || state.method_26164(class_3481.field_29193);
    }

    private static boolean isStone(class_2680 state) {
        class_2248 block = state.method_26204();
        return block == class_2246.field_10340 || block == class_2246.field_28888 || block == class_2246.field_10115 ||
                block == class_2246.field_10474 || block == class_2246.field_10508 || block == class_2246.field_27165;
    }

    private static class_1799 getRandomGem() {
        return switch (RANDOM.nextInt(5)) {
            case 0 -> new class_1799(class_1802.field_8477, 1);
            case 1 -> new class_1799(class_1802.field_8687, 1);
            case 2 -> new class_1799(class_1802.field_8759, RANDOM.nextInt(3) + 1);
            case 3 -> new class_1799(class_1802.field_27063, RANDOM.nextInt(2) + 1);
            default -> new class_1799(class_1802.field_8155, RANDOM.nextInt(2) + 1);
        };
    }

    private static void dropItem(class_3218 world, class_2338 pos, class_1799 stack) {
        class_1542 entity = new class_1542(world, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, stack);
        world.method_8649(entity);
    }

    private static List<class_2338> getAdjacentPositions(class_2338 pos) {
        return List.of(
                pos.method_10084(), pos.method_10074(), pos.method_10095(), pos.method_10072(), pos.method_10078(), pos.method_10067()
        );
    }

    private static int fellTree(class_3218 world, class_2338 start, class_3222 player, int maxBlocks) {
        Set<class_2338> visited = new HashSet<>();
        Queue<class_2338> toVisit = new LinkedList<>();
        toVisit.add(start);
        int broken = 0;

        while (!toVisit.isEmpty() && broken < maxBlocks) {
            class_2338 current = toVisit.poll();
            if (visited.contains(current)) continue;
            visited.add(current);

            class_2680 state = world.method_8320(current);
            if (!state.method_26164(class_3481.field_15475)) continue;

            if (!current.equals(start)) {
                world.method_8651(current, true, player);
                broken++;
            }

            // Check all adjacent blocks and blocks above
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    for (int dy = 0; dy <= 1; dy++) {
                        class_2338 next = current.method_10069(dx, dy, dz);
                        if (!visited.contains(next)) {
                            toVisit.add(next);
                        }
                    }
                }
            }
        }
        return broken;
    }
}
