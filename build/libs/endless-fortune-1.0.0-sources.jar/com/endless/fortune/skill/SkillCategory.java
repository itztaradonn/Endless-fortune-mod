package com.endless.fortune.skill;

import net.minecraft.class_124;

public enum SkillCategory {
    COMBAT("Combat", class_124.field_1061),
    UTILITY("Utility", class_124.field_1078),
    GATHERING("Gathering", class_124.field_1060);

    private final String displayName;
    private final class_124 color;

    SkillCategory(String displayName, class_124 color) {
        this.displayName = displayName;
        this.color = color;
    }

    public String getDisplayName() {
        return displayName;
    }

    public class_124 getColor() {
        return color;
    }
}
