package com.endless.fortune.skill;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.item.ModItems;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1613;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3489;
import net.minecraft.class_8111;
import net.minecraft.class_9334;
import java.util.*;

public class SkillAbilityHandler {

    // Existing cooldowns
    private static final Map<UUID, Long> IMMORTAL_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> SMOKE_BOMB_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Long> STEALTH_COOLDOWN = new HashMap<>();
    private static final Map<UUID, Integer> SNEAK_TICK_COUNTER = new HashMap<>();
    private static final Map<UUID, Long> NECRO_RES_COOLDOWN = new HashMap<>();
    private static final Map<UUID, List<Long>> ALCHEMIST_POTION_TIMESTAMPS = new HashMap<>();

    // Ultimate tracking maps
    private static final Map<UUID, List<Long>> KILL_TIMESTAMPS = new HashMap<>();
    private static final Map<UUID, List<Long>> HIT_TAKEN_TIMESTAMPS = new HashMap<>();
    private static final Map<UUID, Integer> ARROW_HIT_STREAK = new HashMap<>();
    private static final Map<UUID, Long> LAST_ARROW_HIT_TIME = new HashMap<>();
    private static final Map<UUID, Integer> NECRO_KILL_COUNT = new HashMap<>();
    private static final Map<UUID, Integer> SPRINT_TICKS = new HashMap<>();
    private static final Map<UUID, Integer> INVISIBLE_KILLS = new HashMap<>();
    private static final Map<UUID, Integer> WATER_TICKS = new HashMap<>();
    private static final Map<UUID, Long> ULTIMATE_COOLDOWN = new HashMap<>();
    private static final Map<UUID, String> ULTIMATE_READY = new HashMap<>();
    private static final Map<UUID, Long> LAST_ULTIMATE_COOLDOWN_ACTIONBAR = new HashMap<>();

    // Block break counters (used by BlockBreakHandler)
    public static final Map<UUID, Integer> BLOCKS_MINED = new HashMap<>();
    public static final Map<UUID, Integer> CROPS_HARVESTED = new HashMap<>();
    public static final Map<UUID, Integer> LOGS_CHOPPED = new HashMap<>();

    // Active ultimate buff tracking
    private static final Map<UUID, Long> DEAD_EYE_ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> MOTHERLODE_ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> ARCANE_SURGE_ACTIVE = new HashMap<>();
    private static final Set<UUID> APPLYING_MODIFIED_DAMAGE = new HashSet<>();

    private static final long ULTIMATE_GLOBAL_COOLDOWN = 2400L; // 2 min cooldown
    private static final double POTION_OF_FORTUNE_LUCK_COST = 20.0;

    public static void register() {
        // Tick-based passive abilities
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                handlePassiveAbilities(player);
            }
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            UUID entityUuid = entity.method_5667();
            if (APPLYING_MODIFIED_DAMAGE.remove(entityUuid)) {
                return true;
            }

            float adjustedAmount = amount;

            class_3222 attacker = resolveAttackingPlayer(source);
            if (attacker != null && isPlayerCombatHit(source, attacker)) {
                handlePlayerAttacking(attacker, entity, source);
                adjustedAmount = modifyOutgoingDamage(attacker, entity, source, adjustedAmount);
            }

            if (entity instanceof class_3222 targetPlayer) {
                adjustedAmount = modifyIncomingDamage(targetPlayer, source, adjustedAmount);
                if (!handlePlayerDamaged(targetPlayer, source, adjustedAmount)) {
                    return false;
                }
                if (attacker != null) {
                    trackPlayerProjectileHit(attacker, targetPlayer, source);
                }
            }

            if (Math.abs(adjustedAmount - amount) > 0.001f) {
                if (adjustedAmount <= 0.0f) {
                    return false;
                }
                if (entity.method_73183() instanceof class_3218 world) {
                    APPLYING_MODIFIED_DAMAGE.add(entityUuid);
                    entity.method_64397(world, source, adjustedAmount);
                    return false;
                }
            }

            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            class_3222 player = resolveAttackingPlayer(source);
            if (player != null) {
                handlePlayerKill(player, entity);
                if (entity instanceof class_3222 deadPlayer && deadPlayer != player) {
                    dropPotionOfFortuneOnPvpDeath(deadPlayer);
                }
            }
            // Check if arrow from player killed the entity
            if (source.method_5526() instanceof class_1676 projectile) {
                if (projectile.method_24921() instanceof class_3222 projectileOwner) {
                    handleProjectileKill(projectileOwner, entity);
                }
            }
        });
    }

    // ═══════════════════════════════════════
    // PASSIVE ABILITIES (tick-based)
    // ═══════════════════════════════════════
    private static void handlePassiveAbilities(class_3222 player) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;
        expireTimedUltimateStates(player);
        showUltimateCooldownActionbar(player);

        // ── EXPLORER ──
        if (data.hasUnlockedAbility("explorer_speed")) {
            if (!player.method_6059(class_1294.field_5904)) {
                player.method_6092(new class_1293(class_1294.field_5904, 300, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("explorer_night_vision")) {
            class_2338 pos = player.method_24515();
            if (player.method_51469().method_22339(pos) < 8) {
                player.method_6092(new class_1293(class_1294.field_5925, 300, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("explorer_dolphin")) {
            if (player.method_5799()) {
                player.method_6092(new class_1293(class_1294.field_5900, 100, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("explorer_no_hunger")) {
            if (player.field_6012 % 100 == 0) { // Every 5 seconds
                player.method_6092(new class_1293(class_1294.field_5922, 20, 0, true, false, false));
            }
        }
        // Explorer ultimate: Wind Walker - sprint tracking
        if (data.hasUnlockedAbility("explorer_windwalker")) {
            handleWindWalkerTracking(player);
        }

        // ── BERSERKER ──
        if (data.hasUnlockedAbility("berserker_unstoppable")) {
            if (player.method_6032() < player.method_6063() * 0.3f) {
                player.method_6092(new class_1293(class_1294.field_5907, 100, 0, true, false, true));
            }
        }

        // ── GUARDIAN ──
        if (data.hasUnlockedAbility("guardian_fortify")) {
            if (player.method_5715()) {
                player.method_6092(new class_1293(class_1294.field_5907, 100, 0, true, false, true));
            }
        }

        // ── MINER ──
        if (data.hasUnlockedAbility("miner_haste")) {
            if (player.method_6047().method_31573(class_3489.field_42614)) {
                player.method_6092(new class_1293(class_1294.field_5917, 100, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("miner_sight")) {
            if (player.method_24515().method_10264() < 60) {
                player.method_6092(new class_1293(class_1294.field_5925, 300, 0, true, false, true));
            }
        }

        // ── LUMBERJACK ──
        if (data.hasUnlockedAbility("lumber_chop")) {
            if (player.method_6047().method_31573(class_3489.field_42612)) {
                player.method_6092(new class_1293(class_1294.field_5917, 100, 0, true, false, true));
            }
        }

        // ── TRICKSTER ──
        if (data.hasUnlockedAbility("trickster_stealth")) {
            handleStealthAbility(player);
        }

        // ── ALCHEMIST ──
        if (data.hasUnlockedAbility("alchemist_resist")) {
            if (player.method_6059(class_1294.field_5899)) {
                player.method_6016(class_1294.field_5899);
            }
            if (player.method_6059(class_1294.field_5920)) {
                player.method_6016(class_1294.field_5920);
            }
        }
        if (data.hasUnlockedAbility("alchemist_extend")) {
            // Refresh positive effects with extra duration every 60 ticks
            if (player.field_6012 % 60 == 0) {
                player.method_6088().forEach((effect, instance) -> {
                    if (instance.method_5584() > 0 && instance.method_5584() < 100 && !effect.comp_349().method_5573()) {
                        // Skip non-beneficial, only extend beneficial
                    }
                    if (effect.comp_349().method_5573() && instance.method_5584() > 20 && instance.method_5584() < 200) {
                        player.method_6092(new class_1293(effect, 
                                (int)(instance.method_5584() * 1.25f), instance.method_5578(), 
                                true, instance.method_5581(), instance.method_5592()));
                    }
                });
            }
        }

        // ── ENCHANTER ──
        if (data.hasUnlockedAbility("enchanter_luck")) {
            if (!player.method_6059(class_1294.field_5926)) {
                player.method_6092(new class_1293(class_1294.field_5926, 300, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("enchanter_repair")) {
            int interval = data.hasUnlockedAbility("enchanter_mastery") ? 100 : 200; // Mastery = 2x faster
            if (player.field_6012 % interval == 0) {
                class_1799 held = player.method_6047();
                if (held.method_7986()) {
                    held.method_7974(held.method_7919() - 1);
                }
                // Also repair offhand with mastery
                if (data.hasUnlockedAbility("enchanter_mastery")) {
                    class_1799 offhand = player.method_6079();
                    if (offhand.method_7986()) {
                        offhand.method_7974(offhand.method_7919() - 1);
                    }
                }
            }
        }
        // Enchanter ultimate: Arcane Surge - check activation
        if (data.hasUnlockedAbility("enchanter_surge")) {
            handleArcaneSurgeCheck(player);
        }
        // Active Arcane Surge - fast repair
        if (ARCANE_SURGE_ACTIVE.containsKey(player.method_5667())) {
            long expiry = ARCANE_SURGE_ACTIVE.get(player.method_5667());
            if (player.method_51469().method_75260() > expiry) {
                ARCANE_SURGE_ACTIVE.remove(player.method_5667());
            } else if (player.field_6012 % 40 == 0) {
                // Repair all inventory items
                for (int i = 0; i < player.method_31548().method_5439(); i++) {
                    class_1799 stack = player.method_31548().method_5438(i);
                    if (stack.method_7986()) {
                        stack.method_7974(stack.method_7919() - 1);
                    }
                }
            }
        }

        // ── FARMER ──
        if (data.hasUnlockedAbility("farmer_growth")) {
            if (player.field_6012 % 100 == 0) { // Every 5 seconds, grow a nearby crop
                growNearbyCrops(player, 3);
            }
        }
        if (data.hasUnlockedAbility("farmer_nature")) {
            if (player.field_6012 % 40 == 0) { // More frequent crop growth
                growNearbyCrops(player, 5);
            }
        }
        if (data.hasUnlockedAbility("farmer_breeding")) {
            // Regeneration when near animals
            if (player.field_6012 % 60 == 0) {
                class_238 box = player.method_5829().method_1014(8);
                List<class_1429> animals = player.method_51469().method_8390(class_1429.class, box, e -> true);
                if (!animals.isEmpty()) {
                    player.method_6092(new class_1293(class_1294.field_5924, 100, 0, true, false, true));
                }
            }
        }
        if (data.hasUnlockedAbility("farmer_nourish")) {
            if (player.field_6012 % 80 == 0 && player.method_7344().method_7586() < 20) {
                player.method_6092(new class_1293(class_1294.field_5922, 20, 0, true, false, false));
            }
        }

        // ── FISHERMAN ──
        if (data.hasUnlockedAbility("fish_patience")) {
            if (player.method_6047().method_31574(class_1802.field_8378)) {
                int luckLevel = 0;
                if (data.hasUnlockedAbility("fish_rain_luck") && player.method_51469().method_8419()) {
                    luckLevel = 2; // Luck III in rain
                } else if (data.hasUnlockedAbility("fish_treasure") && player.method_5799()) {
                    luckLevel = 1; // Luck II in water
                }
                player.method_6092(new class_1293(class_1294.field_5926, 100, luckLevel, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("fish_sea_blessing")) {
            if (player.method_5799()) {
                player.method_6092(new class_1293(class_1294.field_5927, 100, 0, true, false, true));
            }
        }
        if (data.hasUnlockedAbility("fish_double")) {
            if (player.field_6012 % 200 == 0 && player.method_6047().method_31574(class_1802.field_8378) && player.method_5799()) {
                player.method_7255(3);
            }
        }
        // Fisherman ultimate: Poseidon's Blessing - water time tracking
        if (data.hasUnlockedAbility("fish_poseidon")) {
            handlePoseidonTracking(player);
        }
    }

    // ═══════════════════════════════════════
    // ULTIMATE TRACKING METHODS
    // ═══════════════════════════════════════

    private static void handleWindWalkerTracking(class_3222 player) {
        UUID uuid = player.method_5667();
        if (player.method_5624()) {
            int ticks = SPRINT_TICKS.getOrDefault(uuid, 0) + 1;
            SPRINT_TICKS.put(uuid, ticks);
            if (ticks >= 600) { // 30 seconds of sprinting
                if (markUltimateReady(player, "Wind Walker")) {
                    SPRINT_TICKS.put(uuid, 0);
                }
            }
        } else {
            SPRINT_TICKS.put(uuid, 0);
        }
    }

    private static void handlePoseidonTracking(class_3222 player) {
        UUID uuid = player.method_5667();
        if (player.method_5799()) {
            int ticks = WATER_TICKS.getOrDefault(uuid, 0) + 1;
            WATER_TICKS.put(uuid, ticks);
            if (ticks >= 1200) { // 60 seconds in water
                if (markUltimateReady(player, "Poseidon's Blessing")) {
                    WATER_TICKS.put(uuid, 0);
                }
            }
        } else {
            WATER_TICKS.put(uuid, 0);
        }
    }

    private static void handleArcaneSurgeCheck(class_3222 player) {
        if (player.method_5715() && player.field_7520 >= 30) {
            markUltimateReady(player, "Arcane Surge");
        }
    }

    // Called when a projectile (arrow) deals damage to track archer streaks
    public static void onProjectileHit(class_3222 player, class_1297 target) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;

        if (data.hasUnlockedAbility("archer_deadeye")) {
            UUID uuid = player.method_5667();
            long now = player.method_51469().method_75260();
            long lastHit = LAST_ARROW_HIT_TIME.getOrDefault(uuid, 0L);

            // Reset if more than 5 seconds between hits
            if (now - lastHit > 300) {
                ARROW_HIT_STREAK.put(uuid, 0);
            }

            int streak = ARROW_HIT_STREAK.getOrDefault(uuid, 0) + 1;
            ARROW_HIT_STREAK.put(uuid, streak);
            LAST_ARROW_HIT_TIME.put(uuid, now);

            if (streak >= 7) {
                if (markUltimateReady(player, "Dead Eye")) {
                    ARROW_HIT_STREAK.put(uuid, 0);
                }
            }
        }
    }

    // Called by BlockBreakHandler when miner mines 64 blocks
    public static void onMinerUltimate(class_3222 player) {
        markUltimateReady(player, "Motherlode");
    }

    // Called by BlockBreakHandler when lumberjack chops 32 logs
    public static void onLumberjackUltimate(class_3222 player) {
        markUltimateReady(player, "Timber Storm");
    }

    // Called by BlockBreakHandler when farmer harvests 20 crops
    public static void onFarmerUltimate(class_3222 player) {
        markUltimateReady(player, "Harvest Moon");
    }

    public static boolean isMotherlodeActive(UUID uuid) {
        return MOTHERLODE_ACTIVE.containsKey(uuid) && MOTHERLODE_ACTIVE.get(uuid) > 0;
    }

    public static boolean isDeadEyeActive(UUID uuid) {
        return DEAD_EYE_ACTIVE.containsKey(uuid) && DEAD_EYE_ACTIVE.get(uuid) > 0;
    }

    // ═══════════════════════════════════════
    // STEALTH ABILITY
    // ═══════════════════════════════════════
    private static void handleStealthAbility(class_3222 player) {
        UUID uuid = player.method_5667();
        long now = player.method_51469().method_75260();
        long cooldownEnd = STEALTH_COOLDOWN.getOrDefault(uuid, 0L);

        if (player.method_5715() && player.method_18798().method_1027() < 0.001) {
            int ticks = SNEAK_TICK_COUNTER.getOrDefault(uuid, 0) + 1;
            SNEAK_TICK_COUNTER.put(uuid, ticks);

            if (ticks >= 40 && now > cooldownEnd) {
                player.method_6092(new class_1293(class_1294.field_5905, 60, 0, true, false, true));
                STEALTH_COOLDOWN.put(uuid, now + 600);
                SNEAK_TICK_COUNTER.put(uuid, 0);
            }
        } else {
            SNEAK_TICK_COUNTER.put(uuid, 0);
        }
    }

    // ═══════════════════════════════════════
    // DAMAGE HANDLING
    // ═══════════════════════════════════════
    private static boolean handlePlayerDamaged(class_3222 player, class_1282 source, float amount) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return true;

        // Guardian ultimate: Fortress - track hits taken
        if (data.hasUnlockedAbility("guardian_fortress")) {
            UUID uuid = player.method_5667();
            long now = player.method_51469().method_75260();
            List<Long> hits = HIT_TAKEN_TIMESTAMPS.computeIfAbsent(uuid, k -> new ArrayList<>());
            hits.add(now);
            hits.removeIf(t -> now - t > 1200); // Remove hits older than 60s
            if (hits.size() >= 10) {
                if (markUltimateReady(player, "Fortress")) {
                    hits.clear();
                }
            }
        }

        // Guardian - Aegis: 20% chance to negate
        if (data.hasUnlockedAbility("guardian_aegis")) {
            if (player.method_59922().method_43057() < 0.20f) {
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15150.comp_349(),
                        class_3419.field_15248, 1.0f, 1.0f);
                return false;
            }
        }

        // Trickster - Evasion: 15% dodge chance
        if (data.hasUnlockedAbility("trickster_dodge")) {
            if (player.method_59922().method_43057() < 0.15f) {
                player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14879,
                        class_3419.field_15248, 0.5f, 1.5f);
                return false;
            }
        }

        // Guardian - Undying: Survive fatal blow
        if (data.hasUnlockedAbility("guardian_immortal")) {
            if (player.method_6032() - amount <= 0) {
                long now = player.method_51469().method_75260();
                long cooldownEnd = IMMORTAL_COOLDOWN.getOrDefault(player.method_5667(), 0L);
                if (now > cooldownEnd) {
                    player.method_6033(1.0f);
                    player.method_6092(new class_1293(class_1294.field_5898, 100, 1, true, true, true));
                    player.method_6092(new class_1293(class_1294.field_5924, 60, 1, true, true, true));
                    player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14931,
                            class_3419.field_15248, 1.0f, 1.0f);
                    IMMORTAL_COOLDOWN.put(player.method_5667(), now + 12000);
                    return false;
                }
            }
        }

        // Necromancer - Dark Resurrection: Survive fatal blow with wither aura
        if (data.hasUnlockedAbility("necro_resurrection")) {
            if (player.method_6032() - amount <= 0) {
                long now = player.method_51469().method_75260();
                long cooldownEnd = NECRO_RES_COOLDOWN.getOrDefault(player.method_5667(), 0L);
                if (now > cooldownEnd) {
                    player.method_6033(1.0f);
                    player.method_6092(new class_1293(class_1294.field_5924, 100, 2, true, true, true));
                    // Wither aura - apply wither to nearby mobs
                    applyWitherAura(player, 6, 1, 100);
                    player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15163,
                            class_3419.field_15248, 1.0f, 0.5f);
                    player.method_64398(class_2561.method_43470("  Dark Resurrection activated!").method_27695(class_124.field_1064, class_124.field_1067));
                    NECRO_RES_COOLDOWN.put(player.method_5667(), now + 6000); // 5 min cooldown
                    return false;
                }
            }
        }

        // Trickster - Smoke Bomb: Invisibility + Speed at low HP
        if (data.hasUnlockedAbility("trickster_escape")) {
            if (player.method_6032() - amount <= player.method_6063() * 0.2f && player.method_6032() > player.method_6063() * 0.2f) {
                long now = player.method_51469().method_75260();
                long cooldownEnd = SMOKE_BOMB_COOLDOWN.getOrDefault(player.method_5667(), 0L);
                if (now > cooldownEnd) {
                    player.method_6092(new class_1293(class_1294.field_5905, 100, 0, true, true, true));
                    player.method_6092(new class_1293(class_1294.field_5904, 100, 1, true, true, true));
                    player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14917,
                            class_3419.field_15248, 1.0f, 1.0f);
                    SMOKE_BOMB_COOLDOWN.put(player.method_5667(), now + 6000);
                }
            }
        }

        return true;
    }

    // ═══════════════════════════════════════
    // ATTACK HANDLING
    // ═══════════════════════════════════════
    private static void handlePlayerAttacking(class_3222 player, class_1309 target, class_1282 source) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;
        boolean directAttack = isDirectPlayerAttack(source, player);

        // Necromancer - Wither Touch: Apply Wither on melee hit
        if (data.hasUnlockedAbility("necro_wither")) {
            if (directAttack) {
                target.method_6092(new class_1293(class_1294.field_5920, 60, 0, true, true, true));
            }
        }

        // Track arrow hits for archer ultimate
        if (!(target instanceof class_1657) && isPlayerProjectileAttack(source, player)) {
            onProjectileHit(player, target);
        }
    }

    // ═══════════════════════════════════════
    // KILL HANDLING
    // ═══════════════════════════════════════
    private static void handlePlayerKill(class_3222 player, class_1309 killed) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;
        boolean pveKill = isPveKill(killed);

        // Berserker - Bloodlust: Heal 1 heart on kill
        if (data.hasUnlockedAbility("berserker_bloodlust")) {
            player.method_6025(2.0f);
        }

        // Berserker - Frenzy: Speed on kill
        if (data.hasUnlockedAbility("berserker_frenzy")) {
            player.method_6092(new class_1293(class_1294.field_5904, 100, 0, true, true, true));
        }

        // Necromancer - Soul Harvest: Bonus XP
        if (data.hasUnlockedAbility("necro_soul_harvest") && pveKill) {
            player.method_7255(5);
        }

        // Enchanter - Arcane Knowledge: Bonus XP on kill
        if (data.hasUnlockedAbility("enchanter_xp_boost") && pveKill) {
            int bonus = data.hasUnlockedAbility("enchanter_grindstone") ? 5 : 3; // Salvage = 50% more
            player.method_7255(bonus);
        }

        // Trickster - Sticky Fingers: Bonus XP and loot is handled in LootModifier
        if (data.hasUnlockedAbility("trickster_pickpocket") && pveKill) {
            player.method_7255(3);
        }

        // ── ULTIMATE TRACKING: Kill-based ──

        // Berserker - Bloodbath: 5 kills in 30s
        if (data.hasUnlockedAbility("berserker_bloodbath") && pveKill) {
            UUID uuid = player.method_5667();
            long now = player.method_51469().method_75260();
            List<Long> kills = KILL_TIMESTAMPS.computeIfAbsent(uuid, k -> new ArrayList<>());
            kills.add(now);
            kills.removeIf(t -> now - t > 600); // Remove kills older than 30s
            if (kills.size() >= 5) {
                if (markUltimateReady(player, "Bloodbath")) {
                    kills.clear();
                }
            }
        }

        // Necromancer - Soul Storm: 10 kills total
        if (data.hasUnlockedAbility("necro_soulstorm") && pveKill) {
            UUID uuid = player.method_5667();
            int count = NECRO_KILL_COUNT.getOrDefault(uuid, 0) + 1;
            NECRO_KILL_COUNT.put(uuid, count);
            if (count >= 10) {
                if (markUltimateReady(player, "Soul Storm")) {
                    NECRO_KILL_COUNT.put(uuid, 0);
                }
            }
        }

        // Trickster - Shadow Dance: 5 kills while invisible
        if (data.hasUnlockedAbility("trickster_shadowdance")) {
            if (player.method_6059(class_1294.field_5905)) {
                UUID uuid = player.method_5667();
                int count = INVISIBLE_KILLS.getOrDefault(uuid, 0) + 1;
                INVISIBLE_KILLS.put(uuid, count);
                if (count >= 5) {
                    if (markUltimateReady(player, "Shadow Dance")) {
                        INVISIBLE_KILLS.put(uuid, 0);
                    }
                }
            }
        }
    }

    private static void handleProjectileKill(class_3222 player, class_1309 killed) {
        // Arrow kills also count for kill tracking but are handled by handlePlayerKill
        // This is for additional arrow-specific tracking
    }

    // ═══════════════════════════════════════
    // OUTGOING DAMAGE MODIFICATION
    // ═══════════════════════════════════════
    public static float modifyOutgoingDamage(class_3222 player, class_1309 target, class_1282 source, float originalDamage) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return originalDamage;

        float damage = originalDamage;
        boolean directAttack = isDirectPlayerAttack(source, player);
        boolean projectileAttack = isPlayerProjectileAttack(source, player);

        // Berserker - Rage: +20% damage below 50% HP
        if (data.hasUnlockedAbility("berserker_rage") && directAttack) {
            if (player.method_6032() < player.method_6063() * 0.5f) {
                damage *= 1.20f;
            }
        }

        // Berserker - War Cry: +40% damage below 25% HP
        if (data.hasUnlockedAbility("berserker_warcry") && directAttack) {
            if (player.method_6032() < player.method_6063() * 0.25f) {
                damage *= 1.40f;
            }
        }

        // Archer - Steady Aim: +15% arrow damage
        if (data.hasUnlockedAbility("archer_steady")) {
            if (projectileAttack) {
                damage *= 1.15f;
            }
        }

        // Archer - Quick Draw: Partially-charged arrows deal bonus damage
        if (data.hasUnlockedAbility("archer_quickdraw")) {
            if (projectileAttack) {
                damage *= 1.10f; // Flat 10% bonus representing quickdraw advantage
            }
        }

        // Archer - Piercing Shot: 15% chance for +30% armor-piercing damage
        if (data.hasUnlockedAbility("archer_pierce")) {
            if (projectileAttack) {
                if (player.method_59922().method_43057() < 0.15f) {
                    damage *= 1.30f;
                }
            }
        }

        // Archer - Multi Shot: 10% chance for double damage
        if (data.hasUnlockedAbility("archer_multishot")) {
            if (projectileAttack) {
                if (player.method_59922().method_43057() < 0.10f) {
                    damage *= 2.0f;
                }
            }
        }

        // Archer - Sniper: +50% damage at long range (>20 blocks)
        if (data.hasUnlockedAbility("archer_sniper") && projectileAttack) {
            double distance = player.method_5739(target);
            if (distance > 20.0) {
                damage *= 1.50f;
            }
        }

        // Archer - Dead Eye active: double damage
        if (isDeadEyeActive(player.method_5667()) && projectileAttack) {
            damage *= 1.50f;
        }

        // Necromancer - Life Drain: Heal 0.5 hearts on hit
        if (data.hasUnlockedAbility("necro_drain") && directAttack) {
            player.method_6025(1.0f);
        }

        // Trickster - Backstab: +50% from behind
        if (data.hasUnlockedAbility("trickster_backstab")) {
            double angleDiff = getAngleDifference(player, target);
            if (angleDiff < 60) {
                damage *= 1.50f;
            }
        }

        return damage;
    }

    // ═══════════════════════════════════════
    // INCOMING DAMAGE MODIFICATION
    // ═══════════════════════════════════════
    public static float modifyIncomingDamage(class_3222 player, class_1282 source, float originalDamage) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return originalDamage;

        float damage = originalDamage;
        class_1309 attacker = resolveLivingAttacker(source);

        // Guardian - Iron Skin: 10% damage reduction
        if (data.hasUnlockedAbility("guardian_shield")) {
            damage *= 0.90f;
        }

        // Explorer - Feather Step: 50% less fall damage
        if (data.hasUnlockedAbility("explorer_no_fall")) {
            if (source.method_49708(class_8111.field_42345)) {
                damage *= 0.50f;
            }
        }

        // Necromancer - Undead Pact: 50% less damage from undead
        if (data.hasUnlockedAbility("necro_undead_friend")) {
            if (attacker instanceof class_1642 || attacker instanceof class_1613) {
                damage *= 0.50f;
            }
        }

        // Guardian - Thorns Aura: Reflect 1 heart damage
        if (data.hasUnlockedAbility("guardian_thorns")) {
            if (attacker != null && attacker != player && !source.method_49708(class_8111.field_42330)) {
                if (player.method_51469() instanceof class_3218 serverWorld) {
                    attacker.method_64397(serverWorld, player.method_48923().method_48818(player), 2.0f);
                }
            }
        }

        return damage;
    }

    // ═══════════════════════════════════════
    // UTILITY METHODS
    // ═══════════════════════════════════════

    private static boolean canActivateUltimate(class_3222 player) {
        UUID uuid = player.method_5667();
        long now = player.method_51469().method_75260();
        long cooldownEnd = ULTIMATE_COOLDOWN.getOrDefault(uuid, 0L);
        return now > cooldownEnd;
    }

    private static long getUltimateCooldownRemainingTicks(class_3222 player) {
        long now = player.method_51469().method_75260();
        long cooldownEnd = ULTIMATE_COOLDOWN.getOrDefault(player.method_5667(), 0L);
        return Math.max(0L, cooldownEnd - now);
    }

    private static void showUltimateCooldownActionbar(class_3222 player) {
        UUID uuid = player.method_5667();
        long remainingTicks = getUltimateCooldownRemainingTicks(player);
        if (remainingTicks <= 0L) {
            LAST_ULTIMATE_COOLDOWN_ACTIONBAR.remove(uuid);
            return;
        }

        long secondsRemaining = (remainingTicks + 19L) / 20L;
        Long lastShown = LAST_ULTIMATE_COOLDOWN_ACTIONBAR.get(uuid);
        if (lastShown != null && lastShown == secondsRemaining) {
            return;
        }

        LAST_ULTIMATE_COOLDOWN_ACTIONBAR.put(uuid, secondsRemaining);
        player.method_7353(class_2561.method_43470("Ultimate CD: ").method_27692(class_124.field_1064)
                .method_10852(class_2561.method_43470(formatUltimateCooldown(remainingTicks)).method_27695(class_124.field_1076, class_124.field_1067)), true);
    }

    private static String formatUltimateCooldown(long remainingTicks) {
        long totalSeconds = (remainingTicks + 19L) / 20L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        return String.format("%d:%02d", minutes, seconds);
    }

    private static boolean markUltimateReady(class_3222 player, String name) {
        UUID uuid = player.method_5667();
        if (!canActivateUltimate(player)) return false;
        if (ULTIMATE_READY.containsKey(uuid)) return false;
        ULTIMATE_READY.put(uuid, name);

        player.method_7353(class_2561.method_43470("Ultimate READY: ").method_27695(class_124.field_1076, class_124.field_1067)
                .method_10852(class_2561.method_43470(name).method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470(" (press ").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43472("key.endlessfortune.activate_ultimate").method_27695(class_124.field_1075, class_124.field_1067))
                .method_10852(class_2561.method_43470(")").method_27692(class_124.field_1080)), true);
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14561, class_3419.field_15248, 0.8f, 1.2f);
        return true;
    }

    public static void tryActivateReadyUltimate(class_3222 player) {
        UUID uuid = player.method_5667();
        String name = ULTIMATE_READY.get(uuid);
        if (name == null) {
            player.method_7353(class_2561.method_43470("No ultimate is READY.").method_27692(class_124.field_1080), true);
            return;
        }
        if (!canActivateUltimate(player)) {
            ULTIMATE_READY.remove(uuid);
            player.method_7353(class_2561.method_43470("Ultimate not available (cooldown).").method_27692(class_124.field_1061), true);
            return;
        }

        if (!applyUltimate(player, name)) {
            return;
        }

        ULTIMATE_READY.remove(uuid);
        activateUltimate(player, name);
    }

    public static void onPotionConsumed(class_3222 player, class_1799 consumedPotion) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;

        if (data.hasUnlockedAbility("alchemist_double_brew")
                && player.method_59922().method_43057() < 0.25f
                && modifyConsumedPotionEffects(player, consumedPotion, 2.0, 0)) {
            player.method_7353(class_2561.method_43470("Double Brew!").method_27695(class_124.field_1075, class_124.field_1056), true);
        }

        if (data.hasUnlockedAbility("alchemist_philosopher")) {
            modifyConsumedPotionEffects(player, consumedPotion, 1.0, 1);
        }

        if (data.hasUnlockedAbility("alchemist_elixir")) {
            UUID uuid = player.method_5667();
            long now = player.method_51469().method_75260();
            List<Long> uses = ALCHEMIST_POTION_TIMESTAMPS.computeIfAbsent(uuid, key -> new ArrayList<>());
            uses.add(now);
            uses.removeIf(time -> now - time > 2400);

            if (uses.size() >= 5 && markUltimateReady(player, "Elixir Master")) {
                uses.clear();
            }
        }
    }

    public static void onSplashPotionEffect(class_3222 player) {
        PlayerData data = PlayerDataManager.get(player);
        if (data.getSkill() == null) return;

        if (data.hasUnlockedAbility("alchemist_splash_range")) {
            player.method_6092(new class_1293(class_1294.field_5924, 100, 0, true, true, true));
        }
    }

    private static boolean applyUltimate(class_3222 player, String name) {
        UUID uuid = player.method_5667();
        long now = player.method_51469().method_75260();

        switch (name) {
            case "Wind Walker" -> {
                player.method_6092(new class_1293(class_1294.field_5904, 600, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5913, 600, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5906, 600, 0, true, true, true));
                return true;
            }
            case "Poseidon's Blessing" -> {
                player.method_6092(new class_1293(class_1294.field_5926, 1200, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5900, 1200, 0, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5927, 1200, 0, true, true, true));
                return true;
            }
            case "Arcane Surge" -> {
                if (!player.method_5715() || player.field_7520 < 30) {
                    player.method_7353(class_2561.method_43470("Arcane Surge requires sneaking with 30+ levels.").method_27692(class_124.field_1061), true);
                    return false;
                }
                player.method_7316(-10);
                player.method_6092(new class_1293(class_1294.field_5926, 1200, 1, true, true, true));
                ARCANE_SURGE_ACTIVE.put(uuid, now + 1200);
                return true;
            }
            case "Dead Eye" -> {
                player.method_6092(new class_1293(class_1294.field_5910, 200, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5904, 200, 1, true, true, true));
                DEAD_EYE_ACTIVE.put(uuid, now + 200);
                return true;
            }
            case "Motherlode" -> {
                player.method_6092(new class_1293(class_1294.field_5917, 600, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5925, 600, 0, true, true, true));
                MOTHERLODE_ACTIVE.put(uuid, now + 600);
                return true;
            }
            case "Timber Storm" -> {
                player.method_6092(new class_1293(class_1294.field_5917, 600, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5910, 600, 1, true, true, true));
                return true;
            }
            case "Harvest Moon" -> {
                player.method_6092(new class_1293(class_1294.field_5922, 1200, 1, true, true, true));
                player.method_6092(new class_1293(class_1294.field_18980, 1200, 0, true, true, true));
                growNearbyCrops(player, 8);
                growNearbyCrops(player, 8);
                return true;
            }
            case "Fortress" -> {
                player.method_6092(new class_1293(class_1294.field_5907, 400, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5898, 400, 4, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5924, 400, 1, true, true, true));
                return true;
            }
            case "Bloodbath" -> {
                player.method_6092(new class_1293(class_1294.field_5910, 300, 2, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5904, 300, 1, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5918, 300, 0, true, true, true));
                return true;
            }
            case "Soul Storm" -> {
                applyWitherAura(player, 8, 1, 200);
                player.method_6092(new class_1293(class_1294.field_5924, 200, 2, true, true, true));
                return true;
            }
            case "Elixir Master" -> {
                if (!refreshBeneficialEffects(player, 2.0, 0, 600)) {
                    player.method_7353(class_2561.method_43470("Elixir Master needs an active positive effect.").method_27692(class_124.field_1061), true);
                    return false;
                }
                return true;
            }
            case "Shadow Dance" -> {
                player.method_6092(new class_1293(class_1294.field_5905, 300, 0, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5904, 300, 1, true, true, true));
                player.method_6092(new class_1293(class_1294.field_5910, 300, 0, true, true, true));
                return true;
            }
            default -> {
                player.method_7353(class_2561.method_43470("Unknown ultimate: " + name).method_27692(class_124.field_1061), true);
                return false;
            }
        }
    }

    private static void activateUltimate(class_3222 player, String name) {
        UUID uuid = player.method_5667();
        ULTIMATE_COOLDOWN.put(uuid, player.method_51469().method_75260() + ULTIMATE_GLOBAL_COOLDOWN);
        showUltimateCooldownActionbar(player);

        player.method_7353(class_2561.method_43470("ULTIMATE: ").method_27695(class_124.field_1076, class_124.field_1067)
                .method_10852(class_2561.method_43470(name).method_27695(class_124.field_1065, class_124.field_1067)), true);
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_15195,
                class_3419.field_15248, 1.0f, 1.2f);
        player.method_51469().method_8396(null, player.method_24515(), class_3417.field_14671,
                class_3419.field_15248, 0.3f, 1.5f);
    }

    private static class_3222 resolveAttackingPlayer(class_1282 source) {
        if (source.method_5529() instanceof class_3222 player) {
            return player;
        }
        if (source.method_5526() instanceof class_1676 projectile && projectile.method_24921() instanceof class_3222 player) {
            return player;
        }
        return null;
    }

    private static class_1309 resolveLivingAttacker(class_1282 source) {
        if (source.method_5529() instanceof class_1309 attacker) {
            return attacker;
        }
        if (source.method_5526() instanceof class_1676 projectile && projectile.method_24921() instanceof class_1309 attacker) {
            return attacker;
        }
        return null;
    }

    private static boolean isPlayerCombatHit(class_1282 source, class_3222 player) {
        return isDirectPlayerAttack(source, player) || isPlayerProjectileAttack(source, player);
    }

    private static void trackPlayerProjectileHit(class_3222 attacker, class_3222 targetPlayer, class_1282 source) {
        if (attacker == targetPlayer) {
            return;
        }
        if (isPlayerProjectileAttack(source, attacker)) {
            onProjectileHit(attacker, targetPlayer);
        }
    }

    private static boolean isDirectPlayerAttack(class_1282 source, class_3222 player) {
        return source.method_49708(class_8111.field_42320) && source.method_5529() == player;
    }

    private static boolean isPlayerProjectileAttack(class_1282 source, class_3222 player) {
        return source.method_5526() instanceof class_1676 projectile && projectile.method_24921() == player;
    }

    private static boolean isPveKill(class_1309 killed) {
        return !(killed instanceof class_1657);
    }

    private static void dropPotionOfFortuneOnPvpDeath(class_3222 deadPlayer) {
        PlayerData data = PlayerDataManager.get(deadPlayer);
        if (data.getLuck() < POTION_OF_FORTUNE_LUCK_COST) {
            return;
        }

        data.setLuck(data.getLuck() - POTION_OF_FORTUNE_LUCK_COST);
        data.checkAndUnlockAbilities();
        PlayerDataManager.save(deadPlayer.method_5667());
        deadPlayer.method_7329(new class_1799(ModItems.POTION_OF_FORTUNE), true, false);
        deadPlayer.method_7353(class_2561.method_43470("Dropped Potion of Fortune on death (-20% Luck)").method_27692(class_124.field_1061), false);
    }

    private static void expireTimedUltimateStates(class_3222 player) {
        UUID uuid = player.method_5667();
        long now = player.method_51469().method_75260();

        if (DEAD_EYE_ACTIVE.getOrDefault(uuid, 0L) <= now) {
            DEAD_EYE_ACTIVE.remove(uuid);
        }
        if (MOTHERLODE_ACTIVE.getOrDefault(uuid, 0L) <= now) {
            MOTHERLODE_ACTIVE.remove(uuid);
        }
    }

    private static void applyWitherAura(class_3222 player, int radius, int amplifier, int duration) {
        class_238 box = player.method_5829().method_1014(radius);
        List<class_1309> entities = player.method_51469().method_8390(class_1309.class, box,
                e -> e != player && e instanceof class_1588);
        for (class_1309 entity : entities) {
            entity.method_6092(new class_1293(class_1294.field_5920, duration, amplifier, true, true, true));
        }
    }

    private static boolean modifyConsumedPotionEffects(class_3222 player, class_1799 consumedPotion, double durationMultiplier, int amplifierBonus) {
        class_1844 potionContents = consumedPotion.method_58695(class_9334.field_49651, class_1844.field_49274);
        float durationScale = consumedPotion.method_58695(class_9334.field_55879, 1.0f);
        List<class_1293> consumedEffects = new ArrayList<>();
        potionContents.method_57402(consumedEffects::add, durationScale);
        boolean applied = false;

        for (class_1293 instance : consumedEffects) {
            if (!instance.method_5579().comp_349().method_5573()) {
                continue;
            }

            class_1293 activeInstance = player.method_6112(instance.method_5579());
            if (activeInstance == null) {
                continue;
            }

            int newDuration = Math.max(activeInstance.method_5584(), Math.max(20, (int) Math.round(instance.method_5584() * durationMultiplier)));
            int newAmplifier = Math.max(activeInstance.method_5578(), Math.max(0, instance.method_5578() + amplifierBonus));
            if (newDuration == activeInstance.method_5584() && newAmplifier == activeInstance.method_5578()) {
                continue;
            }

            player.method_6092(new class_1293(instance.method_5579(), newDuration, newAmplifier,
                    activeInstance.method_5591(), activeInstance.method_5581(), activeInstance.method_5592()));
            applied = true;
        }

        return applied;
    }

    private static void modifyBeneficialEffects(class_3222 player, double durationMultiplier, int amplifierBonus) {
        List<class_1293> activeEffects = new ArrayList<>(player.method_6088().values());

        for (class_1293 instance : activeEffects) {
            if (!instance.method_5579().comp_349().method_5573()) {
                continue;
            }

            int newDuration = Math.max(20, (int) Math.round(instance.method_5584() * durationMultiplier));
            int newAmplifier = Math.max(0, instance.method_5578() + amplifierBonus);
            player.method_6092(new class_1293(instance.method_5579(), newDuration, newAmplifier,
                    instance.method_5591(), instance.method_5581(), instance.method_5592()));
        }
    }

    private static boolean refreshBeneficialEffects(class_3222 player, double durationMultiplier, int amplifierBonus, int minimumDuration) {
        List<class_1293> activeEffects = new ArrayList<>(player.method_6088().values());
        boolean applied = false;

        for (class_1293 instance : activeEffects) {
            if (!instance.method_5579().comp_349().method_5573()) {
                continue;
            }

            int newDuration = Math.max(minimumDuration, (int) Math.round(instance.method_5584() * durationMultiplier));
            int newAmplifier = Math.max(0, instance.method_5578() + amplifierBonus);
            player.method_6092(new class_1293(instance.method_5579(), newDuration, newAmplifier,
                    instance.method_5591(), instance.method_5581(), instance.method_5592()));
            applied = true;
        }

        return applied;
    }

    private static void growNearbyCrops(class_3222 player, int radius) {
        if (!(player.method_51469() instanceof class_3218 world)) return;
        class_2338 center = player.method_24515();
        net.minecraft.class_5819 random = world.method_8409();
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                for (int y = -2; y <= 2; y++) {
                    class_2338 pos = center.method_10069(x, y, z);
                    class_2680 state = world.method_8320(pos);
                    if (state.method_26204() instanceof class_2302 crop) {
                        if (!crop.method_9825(state)) {
                            if (random.method_43057() < 0.1f) { // 10% chance per crop per tick
                                crop.method_9652(world, random, pos, state);
                            }
                        }
                    }
                }
            }
        }
    }

    private static double getAngleDifference(class_1657 attacker, class_1309 target) {
        double dx = attacker.method_23317() - target.method_23317();
        double dz = attacker.method_23321() - target.method_23321();
        double attackerAngle = Math.toDegrees(Math.atan2(dz, dx));
        double targetYaw = target.method_36454();
        double diff = Math.abs(attackerAngle - targetYaw) % 360;
        if (diff > 180) diff = 360 - diff;
        return diff;
    }
}
