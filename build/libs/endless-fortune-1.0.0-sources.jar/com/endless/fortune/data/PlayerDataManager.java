package com.endless.fortune.data;

import com.endless.fortune.EndlessFortune;
import com.endless.fortune.item.ModItems;
import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillManager;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {

    private static final Map<UUID, PlayerData> playerDataMap = new HashMap<>();
    private static MinecraftServer server;

    public static void setServer(MinecraftServer srv) {
        server = srv;
        loadAll();
    }

    public static PlayerData getOrCreate(UUID uuid) {
        return playerDataMap.computeIfAbsent(uuid, PlayerData::new);
    }

    public static PlayerData get(class_3222 player) {
        return getOrCreate(player.method_5667());
    }

    public static void onPlayerJoin(class_3222 player) {
        PlayerData data = getOrCreate(player.method_5667());

        // Starter items (only if missing)
        if (!player.method_31548().method_7379(new class_1799(ModItems.GUIDE_BOOK))) {
            player.method_31548().method_7394(new class_1799(ModItems.GUIDE_BOOK));
        }

        if (data.getSkillId() == null) {
            Skill randomSkill = SkillManager.getRandomSkill();
            data.setSkillId(randomSkill.getId());
            player.method_7353(class_2561.method_43470("Assigned Skill: ").method_27695(class_124.field_1065, class_124.field_1067)
                    .method_10852(class_2561.method_43470(randomSkill.getName()).method_27695(randomSkill.getCategory().getColor(), class_124.field_1067))
                    .method_10852(class_2561.method_43470(" (" + randomSkill.getCategory().getDisplayName() + ")").method_27692(class_124.field_1080)), true);

            save(player.method_5667());
        } else {
            data.checkAndUnlockAbilities();
            player.method_64398(class_2561.method_43470("[Endless Fortune] ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470("Welcome back! Skill: ").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(data.getSkill().getName()).method_27695(data.getSkill().getCategory().getColor(), class_124.field_1067))
                    .method_10852(class_2561.method_43470(" | Luck: ").method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470(String.format("%.1f%%", data.getLuck())).method_27692(class_124.field_1060)));
        }
    }

    public static void save(UUID uuid) {
        if (server == null) return;
        try {
            Path dir = getDataDir();
            File dirFile = dir.toFile();
            if (!dirFile.exists()) dirFile.mkdirs();
            Path file = dir.resolve(uuid.toString() + ".dat");
            PlayerData data = playerDataMap.get(uuid);
            if (data != null) {
                class_2507.method_30614(data.toNbt(), file);
            }
        } catch (IOException e) {
            EndlessFortune.LOGGER.error("Failed to save player data for " + uuid, e);
        }
    }

    public static void saveAll() {
        for (UUID uuid : playerDataMap.keySet()) {
            save(uuid);
        }
    }

    public static void loadAll() {
        if (server == null) return;
        File dirFile = getDataDir().toFile();
        if (!dirFile.exists()) return;
        File[] files = dirFile.listFiles((d, name) -> name.endsWith(".dat"));
        if (files == null) return;
        for (File file : files) {
            try {
                class_2487 nbt = class_2507.method_30613(file.toPath(), class_2505.method_53898());
                PlayerData data = PlayerData.fromNbt(nbt);
                playerDataMap.put(data.getPlayerUuid(), data);
            } catch (IOException e) {
                EndlessFortune.LOGGER.error("Failed to load player data from " + file.getName(), e);
            }
        }
    }

    private static Path getDataDir() {
        return server.method_27050(class_5218.field_24188).resolve("endlessfortune");
    }
}
