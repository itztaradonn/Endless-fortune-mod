package com.endless.fortune.data;

import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillManager;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;

public class PlayerData {

    private final UUID playerUuid;
    private double luck;
    private String skillId;
    private final Set<String> completedAdvancements;
    private final Set<String> unlockedAbilities;

    public PlayerData(UUID playerUuid) {
        this.playerUuid = playerUuid;
        this.luck = 0.0;
        this.skillId = null;
        this.completedAdvancements = new HashSet<>();
        this.unlockedAbilities = new HashSet<>();
    }

    public UUID getPlayerUuid() {
        return playerUuid;
    }

    public double getLuck() {
        return luck;
    }

    public void setLuck(double luck) {
        this.luck = Math.max(0.0, Math.min(100.0, luck));
    }

    public void addLuck(double amount) {
        setLuck(this.luck + amount);
    }

    public String getSkillId() {
        return skillId;
    }

    public void setSkillId(String skillId) {
        this.skillId = skillId;
        this.unlockedAbilities.clear();
    }

    public Skill getSkill() {
        if (skillId == null) return null;
        return SkillManager.getSkill(skillId);
    }

    public Set<String> getCompletedAdvancements() {
        return completedAdvancements;
    }

    public boolean hasCompletedAdvancement(String advancementId) {
        return completedAdvancements.contains(advancementId);
    }

    public void addCompletedAdvancement(String advancementId) {
        completedAdvancements.add(advancementId);
    }

    public Set<String> getUnlockedAbilities() {
        return unlockedAbilities;
    }

    public boolean hasUnlockedAbility(String abilityId) {
        return unlockedAbilities.contains(abilityId);
    }

    public void unlockAbility(String abilityId) {
        unlockedAbilities.add(abilityId);
    }

    public void checkAndUnlockAbilities() {
        Skill skill = getSkill();
        if (skill == null) return;
        skill.getAbilities().forEach(ability -> {
            if (luck >= ability.requiredLuck()) {
                unlockedAbilities.add(ability.id());
            } else {
                unlockedAbilities.remove(ability.id());
            }
        });
    }

    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();
        nbt.method_10582("uuid", playerUuid.toString());
        nbt.method_10549("luck", luck);
        if (skillId != null) {
            nbt.method_10582("skillId", skillId);
        }

        class_2499 advList = new class_2499();
        for (String adv : completedAdvancements) {
            advList.add(class_2519.method_23256(adv));
        }
        nbt.method_10566("completedAdvancements", advList);

        class_2499 abilityList = new class_2499();
        for (String ability : unlockedAbilities) {
            abilityList.add(class_2519.method_23256(ability));
        }
        nbt.method_10566("unlockedAbilities", abilityList);

        return nbt;
    }

    public static PlayerData fromNbt(class_2487 nbt) {
        UUID uuid = UUID.fromString(nbt.method_68564("uuid", ""));
        PlayerData data = new PlayerData(uuid);
        data.luck = nbt.method_68563("luck", 0.0);
        String skillIdValue = nbt.method_68564("skillId", "");
        if (!skillIdValue.isEmpty()) {
            data.skillId = skillIdValue;
        }

        class_2499 advList = nbt.method_68569("completedAdvancements");
        for (int i = 0; i < advList.size(); i++) {
            data.completedAdvancements.add(advList.method_68577(i, ""));
        }

        class_2499 abilityList = nbt.method_68569("unlockedAbilities");
        for (int i = 0; i < abilityList.size(); i++) {
            data.unlockedAbilities.add(abilityList.method_68577(i, ""));
        }

        return data;
    }
}
