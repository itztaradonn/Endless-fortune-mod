package com.endless.fortune.luck;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class LootModifier {

    private static final Random RANDOM = new Random();

    // Upgrade map: from item -> to item
    private static final Map<class_1792, class_1792> UPGRADE_MAP = new LinkedHashMap<>();

    static {
        // Weapons
        UPGRADE_MAP.put(class_1802.field_8091, class_1802.field_8528);
        UPGRADE_MAP.put(class_1802.field_8528, class_1802.field_8371);
        UPGRADE_MAP.put(class_1802.field_8371, class_1802.field_8802);
        UPGRADE_MAP.put(class_1802.field_8802, class_1802.field_22022);

        // Pickaxes
        UPGRADE_MAP.put(class_1802.field_8647, class_1802.field_8387);
        UPGRADE_MAP.put(class_1802.field_8387, class_1802.field_8403);
        UPGRADE_MAP.put(class_1802.field_8403, class_1802.field_8377);
        UPGRADE_MAP.put(class_1802.field_8377, class_1802.field_22024);

        // Axes
        UPGRADE_MAP.put(class_1802.field_8406, class_1802.field_8062);
        UPGRADE_MAP.put(class_1802.field_8062, class_1802.field_8475);
        UPGRADE_MAP.put(class_1802.field_8475, class_1802.field_8556);
        UPGRADE_MAP.put(class_1802.field_8556, class_1802.field_22025);

        // Shovels
        UPGRADE_MAP.put(class_1802.field_8876, class_1802.field_8776);
        UPGRADE_MAP.put(class_1802.field_8776, class_1802.field_8699);
        UPGRADE_MAP.put(class_1802.field_8699, class_1802.field_8250);
        UPGRADE_MAP.put(class_1802.field_8250, class_1802.field_22023);

        // Armor - Helmet
        UPGRADE_MAP.put(class_1802.field_8267, class_1802.field_8283);
        UPGRADE_MAP.put(class_1802.field_8283, class_1802.field_8743);
        UPGRADE_MAP.put(class_1802.field_8743, class_1802.field_8805);
        UPGRADE_MAP.put(class_1802.field_8805, class_1802.field_22027);

        // Armor - Chestplate
        UPGRADE_MAP.put(class_1802.field_8577, class_1802.field_8873);
        UPGRADE_MAP.put(class_1802.field_8873, class_1802.field_8523);
        UPGRADE_MAP.put(class_1802.field_8523, class_1802.field_8058);
        UPGRADE_MAP.put(class_1802.field_8058, class_1802.field_22028);

        // Armor - Leggings
        UPGRADE_MAP.put(class_1802.field_8570, class_1802.field_8218);
        UPGRADE_MAP.put(class_1802.field_8218, class_1802.field_8396);
        UPGRADE_MAP.put(class_1802.field_8396, class_1802.field_8348);
        UPGRADE_MAP.put(class_1802.field_8348, class_1802.field_22029);

        // Armor - Boots
        UPGRADE_MAP.put(class_1802.field_8370, class_1802.field_8313);
        UPGRADE_MAP.put(class_1802.field_8313, class_1802.field_8660);
        UPGRADE_MAP.put(class_1802.field_8660, class_1802.field_8285);
        UPGRADE_MAP.put(class_1802.field_8285, class_1802.field_22030);

        // Materials
        UPGRADE_MAP.put(class_1802.field_8713, class_1802.field_8620);
        UPGRADE_MAP.put(class_1802.field_8620, class_1802.field_8695);
        UPGRADE_MAP.put(class_1802.field_8695, class_1802.field_8477);
        UPGRADE_MAP.put(class_1802.field_8477, class_1802.field_8687);
        UPGRADE_MAP.put(class_1802.field_8687, class_1802.field_22020);

        // Food
        UPGRADE_MAP.put(class_1802.field_8229, class_1802.field_8176);
        UPGRADE_MAP.put(class_1802.field_8176, class_1802.field_8463);
        UPGRADE_MAP.put(class_1802.field_8463, class_1802.field_8367);
    }

    /**
     * Modifies loot items based on a player's luck stat.
     * Returns the modified list of items.
     */
    public static List<class_1799> modifyLoot(class_3222 player, List<class_1799> originalLoot) {
        PlayerData data = PlayerDataManager.get(player);
        double luck = data.getLuck();

        if (luck <= 10.0) {
            return originalLoot; // Low luck = normal loot
        }

        List<class_1799> modifiedLoot = new ArrayList<>();
        boolean wasUpgraded = false;

        double upgradeChance = luck / 200.0; // At 100% luck, 50% chance per item

        for (class_1799 stack : originalLoot) {
            if (RANDOM.nextDouble() < upgradeChance) {
                class_1799 upgraded = tryUpgradeItem(stack);
                if (upgraded != stack) {
                    modifiedLoot.add(upgraded);
                    wasUpgraded = true;
                    continue;
                }
            }
            modifiedLoot.add(stack.method_7972());
        }

        // If any item was upgraded, play the amethyst chime
        if (wasUpgraded) {
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_26980, class_3419.field_15248, 1.0f, 1.0f);
            player.method_64398(class_2561.method_43470("  ✧ ").method_27692(class_124.field_1076)
                    .method_10852(class_2561.method_43470("Your luck influenced this loot!").method_27695(class_124.field_1076, class_124.field_1056)));
        }

        return modifiedLoot;
    }

    private static class_1799 tryUpgradeItem(class_1799 original) {
        class_1792 upgraded = UPGRADE_MAP.get(original.method_7909());
        if (upgraded != null) {
            class_1799 newStack = new class_1799(upgraded, original.method_7947());
            // Copy enchantments if any using 1.21.1 component system
            class_9304 enchantments = original.method_58657();
            if (!enchantments.method_57543()) {
                newStack.method_57379(class_9334.field_49633, enchantments);
            }
            // Copy custom name if any
            if (original.method_57826(class_9334.field_49631)) {
                newStack.method_57379(class_9334.field_49631, original.method_7964());
            }
            return newStack;
        }

        // Try to upgrade enchantment levels on enchanted items/books
        class_9304 enchantments = original.method_7909() == class_1802.field_8598
                ? original.method_58695(class_9334.field_49643, class_9304.field_49385)
                : original.method_58657();

        if (!enchantments.method_57543()) {
            class_9304.class_9305 builder = new class_9304.class_9305(class_9304.field_49385);
            boolean changed = false;

            for (class_6880<class_1887> entry : enchantments.method_57534()) {
                int level = enchantments.method_57536(entry);
                int maxLevel = entry.comp_349().method_8183();
                if (level < maxLevel) {
                    builder.method_57550(entry, level + 1);
                    changed = true;
                } else {
                    builder.method_57550(entry, level);
                }
            }

            if (changed) {
                class_1799 copy = original.method_7972();
                if (original.method_7909() == class_1802.field_8598) {
                    copy.method_57379(class_9334.field_49643, builder.method_57549());
                } else {
                    copy.method_57379(class_9334.field_49633, builder.method_57549());
                }
                return copy;
            }
        }

        return original; // No upgrade available
    }
}
