package com.endless.fortune.mixin;

import com.endless.fortune.luck.LuckManager;
import net.minecraft.class_1928;
import net.minecraft.class_2985;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2985.class)
public abstract class AdvancementMixin {

    @Shadow
    private class_3222 owner;

    @Inject(method = "grantCriterion", at = @At("RETURN"))
    private void endlessfortune$onAdvancementGrant(class_8779 advancement, String criterionName,
                                                    CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue() && owner != null) {
            class_2985 tracker = (class_2985)(Object)this;
            if (advancement.comp_1919() != null) {
                var progress = tracker.method_12882(advancement);
                class_3218 world = owner.method_51469();
                boolean announcesInChat = advancement.comp_1920().comp_1913()
                        .map(display -> display.method_808())
                        .orElse(false)
                        && world.method_64395().method_76185(class_1928.field_19409);
                if (progress.method_740() && announcesInChat) {
                    String advancementId = advancement.comp_1919().toString();
                    LuckManager.onAdvancementEarned(owner, advancementId);
                }
            }
        }
    }
}
