package com.endless.fortune.mixin;

import com.endless.fortune.skill.SkillAbilityHandler;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public class PotionItemMixin {

    @Inject(method = "finishUsing", at = @At("RETURN"))
    private void endlessfortune$onPotionConsumed(class_1799 stack, class_1937 world, class_1309 user,
                                                 CallbackInfoReturnable<class_1799> cir) {
        if ((Object) this instanceof class_1812 && !world.method_8608() && user instanceof class_3222 player) {
            SkillAbilityHandler.onPotionConsumed(player, stack);
        }
    }
}
