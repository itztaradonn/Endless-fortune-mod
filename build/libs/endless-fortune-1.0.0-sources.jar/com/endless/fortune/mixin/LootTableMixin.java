package com.endless.fortune.mixin;

import com.endless.fortune.luck.LootModifier;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_181;
import net.minecraft.class_3222;
import net.minecraft.class_47;
import net.minecraft.class_52;

@Mixin(class_52.class)
public class LootTableMixin {

    @Inject(method = "generateLoot(Lnet/minecraft/loot/context/LootContext;)Lit/unimi/dsi/fastutil/objects/ObjectArrayList;",
            at = @At("RETURN"), cancellable = true)
    private void endlessfortune$modifyGeneratedLoot(class_47 context, CallbackInfoReturnable<ObjectArrayList<class_1799>> cir) {
        class_1297 entity = null;
        try {
            entity = context.method_65013(class_181.field_1226);
        } catch (Exception ignored) {
            // LootContextParameters.THIS_ENTITY may not be present in all contexts
        }

        if (entity instanceof class_3222 player) {
            ObjectArrayList<class_1799> originalLoot = cir.getReturnValue();
            if (originalLoot != null && !originalLoot.isEmpty()) {
                List<class_1799> modifiedLoot = LootModifier.modifyLoot(player, originalLoot);
                cir.setReturnValue(new ObjectArrayList<>(modifiedLoot));
            }
        }
    }
}
