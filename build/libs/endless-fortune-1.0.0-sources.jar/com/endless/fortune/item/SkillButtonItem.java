package com.endless.fortune.item;

import com.endless.fortune.skill.SkillAbilityHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

public class SkillButtonItem extends class_1792 {

    public SkillButtonItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        if (!world.method_8608() && user instanceof class_3222 player) {
            SkillAbilityHandler.tryActivateReadyUltimate(player);
            return class_1269.field_5812;
        }
        return class_1269.field_5811;
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
