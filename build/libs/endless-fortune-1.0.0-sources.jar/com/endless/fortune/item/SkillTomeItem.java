package com.endless.fortune.item;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillCategory;
import com.endless.fortune.skill.SkillManager;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class SkillTomeItem extends class_1792 {

    public enum TomeType {
        COMBAT(SkillCategory.COMBAT),
        UTILITY(SkillCategory.UTILITY),
        GATHERING(SkillCategory.GATHERING);

        private final SkillCategory category;

        TomeType(SkillCategory category) {
            this.category = category;
        }

        public SkillCategory getCategory() {
            return category;
        }
    }

    private static final double REQUIRED_LUCK_TO_USE = 100.0;

    private final TomeType tomeType;

    public SkillTomeItem(class_1793 settings, TomeType tomeType) {
        super(settings);
        this.tomeType = tomeType;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!world.method_8608() && user instanceof class_3222 player) {
            PlayerData data = PlayerDataManager.get(player);
            if (data.getLuck() < REQUIRED_LUCK_TO_USE) {
                player.method_7353(class_2561.method_43470("You need ").method_27692(class_124.field_1061)
                        .method_10852(class_2561.method_43470(String.format("%.0f%%", REQUIRED_LUCK_TO_USE)).method_27695(class_124.field_1065, class_124.field_1067))
                        .method_10852(class_2561.method_43470(" Luck to use this tome.").method_27692(class_124.field_1061)), true);
                return class_1269.field_5814;
            }

            // Get a random skill from the specific category
            Skill newSkill = SkillManager.getRandomSkillByCategory(tomeType.getCategory());
            data.setSkillId(newSkill.getId());

            // RESET LUCK to 0
            data.setLuck(0.0);
            data.getCompletedAdvancements().clear();

            // Re-check abilities (should have none since luck is 0)
            data.checkAndUnlockAbilities();

            stack.method_7934(1);

            // Sound
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_17481, class_3419.field_15248, 1.0f, 0.5f);
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_15119, class_3419.field_15248, 1.0f, 0.8f);
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_14865, class_3419.field_15248, 0.5f, 1.5f);

            class_124 color = tomeType.getCategory().getColor();
            player.method_7353(class_2561.method_43470("New Skill: ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470(newSkill.getName()).method_27695(color, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" (Luck reset to 0%)").method_27692(class_124.field_1061)), false);

            player.method_7353(class_2561.method_43470("New Skill: ").method_27692(class_124.field_1065)
                    .method_10852(class_2561.method_43470(newSkill.getName()).method_27695(color, class_124.field_1067))
                    .method_10852(class_2561.method_43470(" (Luck reset to 0%)").method_27692(class_124.field_1061)), true);

            PlayerDataManager.save(player.method_5667());

            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    @Override
    public void method_67187(class_1799 stack, class_1792.class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> tooltip, class_1836 type) {
        class_124 color = tomeType.getCategory().getColor();
        tooltip.accept(class_2561.method_43470("A tome of " + tomeType.getCategory().getDisplayName() + " knowledge.").method_27695(color, class_124.field_1056));
        tooltip.accept(class_2561.method_43470(""));
        tooltip.accept(class_2561.method_43470("Requires 100% Luck to use.").method_27695(class_124.field_1065, class_124.field_1067));
        tooltip.accept(class_2561.method_43470("Right-click to apply.").method_27692(class_124.field_1054));
        tooltip.accept(class_2561.method_43470("Grants a random " + tomeType.getCategory().getDisplayName() + " skill.").method_27692(color));
        tooltip.accept(class_2561.method_43470(""));
        tooltip.accept(class_2561.method_43470("⚠ WARNING: Resets your Luck to 0%!").method_27695(class_124.field_1061, class_124.field_1067));
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
