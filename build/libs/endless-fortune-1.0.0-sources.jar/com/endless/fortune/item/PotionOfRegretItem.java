package com.endless.fortune.item;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillManager;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class PotionOfRegretItem extends class_1792 {

    public PotionOfRegretItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!world.method_8608() && user instanceof class_3222 player) {
            PlayerData data = PlayerDataManager.get(player);
            String oldSkillId = data.getSkillId();
            Skill oldSkill = data.getSkill();

            // Get a new random skill (different from current)
            Skill newSkill;
            int attempts = 0;
            do {
                newSkill = SkillManager.getRandomSkill();
                attempts++;
            } while (newSkill.getId().equals(oldSkillId) && attempts < 20);

            data.setSkillId(newSkill.getId());
            data.checkAndUnlockAbilities();

            // Consume the item
            stack.method_7934(1);

            // Visual + Sound feedback
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_14978, class_3419.field_15248, 1.0f, 0.5f);
            player.method_51469().method_8396(null, player.method_24515(),
                    class_3417.field_15058, class_3419.field_15248, 1.0f, 1.0f);

            player.method_7353(class_2561.method_43470("Rerolled skill → ").method_27692(class_124.field_1064)
                    .method_10852(class_2561.method_43470(newSkill.getName()).method_27695(newSkill.getCategory().getColor(), class_124.field_1067)), true);

            PlayerDataManager.save(player.method_5667());

            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    @Override
    public void method_67187(class_1799 stack, class_1792.class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> tooltip, class_1836 type) {
        tooltip.accept(class_2561.method_43470("A bitter potion brewed from regret.").method_27695(class_124.field_1064, class_124.field_1056));
        tooltip.accept(class_2561.method_43470(""));
        tooltip.accept(class_2561.method_43470("Right-click to reroll your skill.").method_27692(class_124.field_1054));
        tooltip.accept(class_2561.method_43470("Your abilities will be reset!").method_27692(class_124.field_1061));
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
