package com.endless.fortune.item;

import com.endless.fortune.EndlessFortune;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_124;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModItems {

    // Registry keys for items (required since 1.21.2)
    private static final class_5321<class_1792> POTION_OF_REGRET_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "potion_of_regret"));
    private static final class_5321<class_1792> COMBAT_SKILL_TOME_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "combat_skill_tome"));
    private static final class_5321<class_1792> UTILITY_SKILL_TOME_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "utility_skill_tome"));
    private static final class_5321<class_1792> GATHERING_SKILL_TOME_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "gathering_skill_tome"));
    private static final class_5321<class_1792> LUCK_CRYSTAL_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "luck_crystal"));
    private static final class_5321<class_1792> POTION_OF_FORTUNE_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "potion_of_fortune"));
    private static final class_5321<class_1792> GUIDE_BOOK_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "guide_book"));
    private static final class_5321<class_1792> SKILL_BUTTON_KEY = class_5321.method_29179(
            class_7924.field_41197, class_2960.method_60655(EndlessFortune.MOD_ID, "skill_button"));

    // Potion of Regret - rerolls skill
    public static final class_1792 POTION_OF_REGRET = new PotionOfRegretItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_63686(POTION_OF_REGRET_KEY));

    // Skill Tomes - craftable skill items that reset luck
    public static final class_1792 COMBAT_SKILL_TOME = new SkillTomeItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_63686(COMBAT_SKILL_TOME_KEY), SkillTomeItem.TomeType.COMBAT);

    public static final class_1792 UTILITY_SKILL_TOME = new SkillTomeItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_63686(UTILITY_SKILL_TOME_KEY), SkillTomeItem.TomeType.UTILITY);

    public static final class_1792 GATHERING_SKILL_TOME = new SkillTomeItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_63686(GATHERING_SKILL_TOME_KEY), SkillTomeItem.TomeType.GATHERING);

    // Luck Crystal - rare crafting ingredient
    public static final class_1792 LUCK_CRYSTAL = new class_1792(
            new class_1792.class_1793().method_7894(class_1814.field_8907).method_63686(LUCK_CRYSTAL_KEY));

    // Potion of Fortune - restores 20% luck when consumed
    public static final class_1792 POTION_OF_FORTUNE = new PotionOfFortuneItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8904).method_63686(POTION_OF_FORTUNE_KEY), 20.0);

    // Starter items
    public static final class_1792 GUIDE_BOOK = new GuideBookItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_63686(GUIDE_BOOK_KEY));
    public static final class_1792 SKILL_BUTTON = new SkillButtonItem(
            new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903).method_63686(SKILL_BUTTON_KEY));

    // Item Group
    public static final class_5321<class_1761> ENDLESS_FORTUNE_GROUP = class_5321.method_29179(
            class_7924.field_44688, class_2960.method_60655(EndlessFortune.MOD_ID, "endless_fortune"));

    public static void register() {
        // Register items using RegistryKey (required since 1.21.2)
        class_2378.method_39197(class_7923.field_41178, POTION_OF_REGRET_KEY, POTION_OF_REGRET);
        class_2378.method_39197(class_7923.field_41178, COMBAT_SKILL_TOME_KEY, COMBAT_SKILL_TOME);
        class_2378.method_39197(class_7923.field_41178, UTILITY_SKILL_TOME_KEY, UTILITY_SKILL_TOME);
        class_2378.method_39197(class_7923.field_41178, GATHERING_SKILL_TOME_KEY, GATHERING_SKILL_TOME);
        class_2378.method_39197(class_7923.field_41178, LUCK_CRYSTAL_KEY, LUCK_CRYSTAL);
        class_2378.method_39197(class_7923.field_41178, POTION_OF_FORTUNE_KEY, POTION_OF_FORTUNE);
        class_2378.method_39197(class_7923.field_41178, GUIDE_BOOK_KEY, GUIDE_BOOK);
        class_2378.method_39197(class_7923.field_41178, SKILL_BUTTON_KEY, SKILL_BUTTON);

        // Register item group
        class_2378.method_39197(class_7923.field_44687, ENDLESS_FORTUNE_GROUP, FabricItemGroup.builder()
                .method_47320(() -> new class_1799(POTION_OF_REGRET))
                .method_47321(class_2561.method_43470("Endless Fortune").method_27692(class_124.field_1065))
                .method_47317((context, entries) -> {
                    entries.method_45421(POTION_OF_REGRET);
                    entries.method_45421(COMBAT_SKILL_TOME);
                    entries.method_45421(UTILITY_SKILL_TOME);
                    entries.method_45421(GATHERING_SKILL_TOME);
                    entries.method_45421(LUCK_CRYSTAL);
                    entries.method_45421(POTION_OF_FORTUNE);
                    entries.method_45421(GUIDE_BOOK);
                })
                .method_47324());

        EndlessFortune.LOGGER.info("Registered Endless Fortune items!");
    }
}
