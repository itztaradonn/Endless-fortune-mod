package com.endless.fortune.item;

import com.endless.fortune.skill.Skill;
import com.endless.fortune.skill.SkillAbility;
import com.endless.fortune.skill.SkillCategory;
import com.endless.fortune.skill.SkillManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_9262;
import net.minecraft.class_9302;
import net.minecraft.class_9334;

public class GuideBookItem extends class_1792 {

    public GuideBookItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        stack.method_57379(class_9334.field_49606, createGuideBookContent());
        user.method_7315(stack, hand);
        return class_1269.field_5812;
    }

    private static class_9302 createGuideBookContent() {
        return new class_9302(
                class_9262.method_57137("Endless Fortune Guide"),
                "Endless Fortune",
                0,
                buildPages(),
                false);
    }

    private static List<class_9262<class_2561>> buildPages() {
        List<class_9262<class_2561>> pages = new ArrayList<>();
        pages.add(page(class_2561.method_43473()
                .method_10852(class_2561.method_43470("Endless Fortune Guide").method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470("\n\nOpen this book anytime for skills, items, and controls.").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("\n\nUltimate Key: ").method_27692(class_124.field_1054))
                .method_10852(class_2561.method_43472("key.endlessfortune.activate_ultimate").method_27695(class_124.field_1075, class_124.field_1067))
                .method_10852(class_2561.method_43470("\nWhen an ultimate becomes READY, press that key to activate it.").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("\n\nCommands:\n/skill\n/skill info <skillId>\n/luck\n/withdraw").method_27692(class_124.field_1063))));

        for (SkillCategory category : SkillCategory.values()) {
            pages.add(page(class_2561.method_43470(category.getDisplayName()).method_27695(category.getColor(), class_124.field_1067)
                    .method_10852(class_2561.method_43470("\n\nSkills in this category:").method_27692(class_124.field_1080))));

            for (Skill skill : SkillManager.getSkillsByCategory(category)) {
                pages.add(buildSkillPage(skill));
            }
        }

        pages.add(page(class_2561.method_43473()
                .method_10852(class_2561.method_43470("Items & Systems").method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470("\n\nPotion of Regret\n").method_27695(class_124.field_1076, class_124.field_1067))
                .method_10852(class_2561.method_43470("Rerolls your current skill.\n\n").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("Potion of Fortune\n").method_27695(class_124.field_1076, class_124.field_1067))
                .method_10852(class_2561.method_43470("Restores 20% luck.\n\n").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("Skill Tomes\n").method_27695(class_124.field_1075, class_124.field_1067))
                .method_10852(class_2561.method_43470("Swap to a Combat, Utility, or Gathering skill and reset luck to 0%.\n\n").method_27692(class_124.field_1080))
                .method_10852(class_2561.method_43470("Guide Book\n").method_27695(class_124.field_1054, class_124.field_1067))
                .method_10852(class_2561.method_43470("Opens this book again whenever you need a reminder.").method_27692(class_124.field_1080))));

        return pages;
    }

    private static class_9262<class_2561> buildSkillPage(Skill skill) {
        class_5250 page = class_2561.method_43473()
                .method_10852(class_2561.method_43470(skill.getName()).method_27695(skill.getCategory().getColor(), class_124.field_1067))
                .method_10852(class_2561.method_43470("\n" + skill.getCategory().getDisplayName()).method_27692(class_124.field_1063))
                .method_10852(class_2561.method_43470("\n\n" + skill.getDescription()).method_27692(class_124.field_1080));

        for (SkillAbility ability : skill.getAbilities()) {
            page = page.method_10852(class_2561.method_43470("\n\n" + String.format("%.0f%% ", ability.requiredLuck())).method_27695(class_124.field_1065, class_124.field_1067))
                    .method_10852(class_2561.method_43470(ability.name()).method_27692(class_124.field_1054))
                    .method_10852(class_2561.method_43470("\n" + ability.description()).method_27692(class_124.field_1080));
        }
        return page(page);
    }

    private static class_9262<class_2561> page(class_2561 text) {
        return class_9262.method_57137(text);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
