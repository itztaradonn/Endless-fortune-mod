package com.endless.fortune.item;

import com.endless.fortune.data.PlayerData;
import com.endless.fortune.data.PlayerDataManager;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

public class PotionOfFortuneItem extends class_1792 {

    private final double luckAmount;

    public PotionOfFortuneItem(class_1793 settings, double luckAmount) {
        super(settings);
        this.luckAmount = luckAmount;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        user.method_6019(hand);
        return class_1269.field_21466;
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (user instanceof class_3222 player) {
            if (!world.method_8608()) {
                PlayerData data = PlayerDataManager.get(player);
                double oldLuck = data.getLuck();
                double newLuck = Math.min(100.0, oldLuck + luckAmount);
                data.setLuck(newLuck);

                // Check for newly unlocked abilities
                data.checkAndUnlockAbilities();
                PlayerDataManager.save(player.method_5667());

                // Effects and messages
                world.method_8396(null, player.method_24515(), class_3417.field_14709,
                        class_3419.field_15248, 1.0f, 1.2f);
                world.method_8396(null, player.method_24515(), class_3417.field_14627,
                        class_3419.field_15248, 0.5f, 1.5f);

                player.method_7353(class_2561.method_43470("Luck +").method_27692(class_124.field_1060)
                        .method_10852(class_2561.method_43470(String.format("%.1f%%", (newLuck - oldLuck))).method_27695(class_124.field_1065, class_124.field_1067))
                        .method_10852(class_2561.method_43470(" (Potion of Fortune)").method_27692(class_124.field_1080)), true);

                stack.method_7934(1);
            }
        }
        return stack;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 32; // Same as vanilla potions
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public void method_67187(class_1799 stack, class_1792.class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> tooltip, class_1836 type) {
        tooltip.accept(class_2561.method_43470("A potion brimming with fortune.").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.accept(class_2561.method_43470(""));
        tooltip.accept(class_2561.method_43470("Restores ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(String.format("%.0f%%", luckAmount)).method_27695(class_124.field_1065, class_124.field_1067))
                .method_10852(class_2561.method_43470(" Luck when consumed.").method_27692(class_124.field_1060)));
        tooltip.accept(class_2561.method_43470(""));
        tooltip.accept(class_2561.method_43470("Obtained via /withdraw").method_27695(class_124.field_1063, class_124.field_1056));
    }

    public double getLuckAmount() {
        return luckAmount;
    }
}
