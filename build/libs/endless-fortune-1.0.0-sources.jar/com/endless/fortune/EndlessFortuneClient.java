package com.endless.fortune;

import com.endless.fortune.network.ActivateUltimatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class EndlessFortuneClient implements ClientModInitializer {

    private static class_304 activateUltimateKey;

    @Override
    public void onInitializeClient() {
        activateUltimateKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.endlessfortune.activate_ultimate",
                GLFW.GLFW_KEY_R,
                class_304.class_11900.field_62558
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (activateUltimateKey.method_1436()) {
                if (client.field_1724 != null && ClientPlayNetworking.canSend(ActivateUltimatePayload.ID)) {
                    ClientPlayNetworking.send(ActivateUltimatePayload.INSTANCE);
                }
            }
        });
    }
}
